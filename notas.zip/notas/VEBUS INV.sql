

--Revisar si esta en Status 'A '(respetar el espacio) en el catalogo general
select * from venus.vdmara
where material_matnr = '000000000011738253'
 
--Revisar si esta en Status 'A 'o 'BC'(respetar el espacio) en la asignacion a la tienda
select * from venus.vdmarc
where centro_werks = '24'
and material_matnr = '000000000011738253'
 
--insert por si no existe
insert into venus.vdmarc (centro_werks,material_matnr,bit_eliminado,fec_movto,issf,statmat_pur_status,caracplanif_mrp_type)
values ('24','000000000011738253',0,now() at time zone 'CST',0,'A ','Z1')
 
 
--Tiene Que existir en Catalogo almacen(Catalogo Ecommerce)
select * from venus.catalogoalmacen_v2
where material_matnr = '000000000011738253'
 
--insert si no exite en el catalogo
insert into venus.catalogoalmacen_v2 (material_matnr,issf,fec_movto,cityclub,soriana,alm1,alm2,alm3,alm4,cit1,cit2,lastalms)
values ('000000000011738253',1,now() at time zone 'CST',0,1,0,1,0,0,0,0,'0000')
 
--Consulta de inventario SETC y DST
SELECT * from venus.vdinvfinal i
where i.material_matnr = '000000000011738253'
and i.centro_werks = '24'
 
--Insert si no existe el registro
insert into venus.vdinvfinal values ('24','000000000011738253',10000,now() at time zone 'CST',0)
 
--Consutla inventario de Cedis
SELECT * from venus.vdinventariocedis i
where i.material_matnr = '11738253'
 
--insert para productos de Cedis
insert into venus.vdinventariocedis (centro_werks,material_matnr,labst,fec_movto,ndecimales,idcompania,nombreproducto,idtipocontenedor,
                                idestadocalidad,inventario,disponible,uni_reservada,disponible_act)
values ('8003','11738253',1000,now() at time zone 'CST',2,1,'Descripcion Prod Generica',1,1,1000,1000,0,1000)
 
 
--Consutla inventario de vendor
SELECT * from venus.vdinventariovendor i
where i.material_matnr = '11738253'
 
--insert para registo no existente en Vendor
insert into venus.vdinventariovendor (numprov_lifnr,clave_almacen,material_matnr,labst,preorden,stock_seguridad,fec_movto,uni_reservada,labst_act)
values ('20751',1,'11738253',1000,0,0,now() at time zone 'CST',0,1000)