using ConsultarPerfilCliente.Services;
using ConsultarPerfilClienteAgil;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net;
using System.Net.Http;

[assembly: FunctionsStartup(typeof(Startup))]
namespace ConsultarPerfilClienteAgil
{
    public class Startup : FunctionsStartup
    {
        public Startup()
        { }
        public override void Configure(IFunctionsHostBuilder builder)
        {
            IConfiguration Configuration = builder.GetContext().Configuration;
            //builder.Services.Configure<IConfiguration>(Configuration)


            builder.Services.AddScoped<IConsultarPerfilService, ConsultarPerfilService>();
            builder.Services.AddScoped<ILogService, LogService>();

            ConfigureHttpClient(builder.Services, Configuration);
            ConfigureCosmosDb(builder.Services, Configuration);
        }

        private void ConfigureHttpClient(IServiceCollection services, IConfiguration Configuration)
        {
            string baseUrl = Configuration["DMZIdentificacionOrq:BaseUrl"];

            services
                .AddHttpClient<IDmzIdentificationService,DmzIdentificationService>(
                    client =>
                    {
                        client.BaseAddress = new Uri(baseUrl);
                        client.Timeout = TimeSpan.FromMilliseconds(30000);
                        //client.DefaultRequestHeaders.Add(functionKey, functionValue);
                        //client.DefaultRequestHeaders.Add(functionTraceKey, functionTraceValue);
                    });
        }

        private void ConfigureCosmosDb(IServiceCollection services, IConfiguration Configuration)
        {

            string EndpointUri = Configuration["CosmosDb:URL"];
            string PrimaryKey = Configuration["CosmosDb:Key"];
            string databaseId = Configuration["CosmosDb:Collection"];
            string containerId = Configuration["CosmosDb:Container"];

            //var cosmosClientOptions = new CosmosClientOptions
            //{
            //    //ConnectionMode = Microsoft.Azure.Cosmos.ConnectionMode.Direct
            //    ConnectionMode = ConnectionMode.Gateway
            //};


            //var cosmosClient = new CosmosClient(EndpointUri,
            //                                    PrimaryKey,
            //                                    cosmosClientOptions);

            Microsoft.Azure.Cosmos.Container defaultContainer = cosmosClient.GetContainer(databaseId, containerId);

            var handler = new HttpClientHandler
            {
                Proxy = new WebProxy("http://172.18.15.84:9090")
                {
                    Credentials = new NetworkCredential("usuario", "contraseña")
                },
                UseProxy = true
            };

            var cosmosClientOptions = new CosmosClientOptions
            {
                HttpClientFactory = () => new HttpClient(handler),
                ConnectionMode = ConnectionMode.Gateway // Gateway funciona mejor con proxies
            };

            var cosmosClient = new CosmosClient(EndpointUri,PrimaryKey, cosmosClientOptions);

            services
                .AddSingleton(cosmosClient);

            services
                .AddSingleton(defaultContainer);

            //services
            //   .AddSingleton<IDocumentClient>(x => new DocumentClient(new Uri(EndpointUri),
            //                                                          PrimaryKey));
        }
    }
}
