
CREATE procedure dbo.upCorpOms_Cns_OrdersByOrderNo_V2    
   @UeNo  varchar(25)       
as     
  
begin              
        
  DECLARE        
   @TotNormal   DECIMAL(18,2) = 0,        
 @TotOferta   DECIMAL(18,2) = 0,        
 @TotNormalSurtido DECIMAL(18,2)  = 0,        
 @TotOfertaSurtido DECIMAL(18,2)  = 0,        
 @TotPOS    DECIMAL(18,2) = 0,        
 @TotPagado   DECIMAL(18,2) = 0,        
 @Ahorro    DECIMAL(18,2) = 0,        
 @PuntosGanados  DECIMAL(18,2) = 0,        
 @PuntosAcumulados DECIMAL(18,2) = 0,        
 @OrderNo   int = 0,        
 @OrderId   int = 0,  -- Call Center      
 @cnscOrder   BIGINT = 0,        
 @cnscOrderOrd  BIGINT = 0,        
 @StoreNum   BIGINT = 0,        
 @Logisticas         INT = 0,        
 @LogLocal   INT = 0,        
 @FlagLocal          INT = 0,      
 @CreatedBy  varchar(25) = null,  -- NO ES LOGISTICA LOCAL        
 @methodname varchar(50),      
 @expectedMethod varchar(50),      
 @methodnameSPA varchar(100);       
        	
declare @auxUeNo int;

set @auxUeNo = cast(replace(@UeNo,'-','') as Int)
          
 SET @UeNo =        
   case when isnumeric(@UeNo)=1 then (SELECT TOP 1 u.UeNo FROM OrderFacts_UE u WHERE convert(varchar, u.OrderNo) = @UeNo)        
    else @UeNo        
   end        
        
    DECLARE @StatusUe TINYINT;        
    DECLARE @IsPickingManual BIT;        
        
 SET @CreatedBy = ISNULL((SELECT TOP 1 CreatedBy FROM OrderFacts_UE WHERE UeNo = @UeNo), '');       
      
    SET @OrderNo = ISNULL((SELECT TOP 1 OrderNo FROM OrderFacts_UE WHERE UeNo = @UeNo), 0);        
 SET @OrderId = ISNULL(SUBSTRING(CONVERT(varchar, @OrderNo), 1, LEN(@OrderNo) - 2), 0); -- Call Center      
    SET @cnscOrder = ISNULL((SELECT TOP 1 CnscOrder FROM OrderFacts_UE WHERE UeNo = @UeNo), 0);        
    SET @cnscOrderOrd = ISNULL((SELECT TOP 1 CnscOrder FROM OrderFacts_Order WHERE OrderNo = @OrderNo), 0);        
    SET @StoreNum = ISNULL((SELECT TOP 1 StoreNum FROM OrderFacts_UE WHERE UeNo = @UeNo), 0);        
    SET @Logisticas = ISNULL((SELECT count(IdTipoLogistica) FROM tms.AlmacenTipoLogistica WHERE idOwner=2 and idSupplierWH=@StoreNum),0);        
    SET @LogLocal = ISNULL((SELECT count(IdTipoLogistica) FROM tms.AlmacenTipoLogistica WHERE idOwner=2 and idSupplierWH=@StoreNum and IdTipoLogistica=1),0);        
    IF @Logisticas = 1 and @LogLocal>0        
      SET @FlagLocal = 1 -- ES LOGISTICA LOCAL        
        
  SELECT top 1 @StatusUe = StatusUe,        
       @IsPickingManual =IsPickingManual        
    FROM OrderFacts_UE WHERE OrderNo = @OrderNo;        
        
    DECLARE @Orderstatus TINYINT = ISNULL((SELECT OrderStatus FROM OrderFacts_POSOrderStatus WHERE OrderNo = @OrderNo),0);          
        
    -- FORMA DE PAGO ORIGINAL      
 declare @temp table      
 (      
   [methodname]  varchar(50),      
   [expectedMethod] varchar(50)      
 );      
 insert INTO @temp      
 EXEC [dbo].[upCorpOms_Cns_OrderPaymentType] @OrderNo;      
      
 SELECT TOP 1 @methodname=methodname, @expectedMethod=expectedMethod      
 FROM @temp;      
      
 SELECT @methodnameSPA =      
 CASE        
 WHEN @methodname='POD' AND @expectedMethod='voucher_card' THEN 'POD - Tarjeta de vales'      
 WHEN @methodname='POD' AND @expectedMethod='cash' THEN 'POD - Pago en efectivo y se solicita el monto con el que va a pagar el cliente'      
 WHEN @methodname='POD' AND @expectedMethod='credit_card' THEN 'POD - Tarjeta Credito/Debito'      
 WHEN @methodname='POD' AND @expectedMethod='debit_card' THEN 'POD - Tarjeta Debito'  
 WHEN @methodname='POD' AND @expectedMethod='visa_master_card' THEN 'POD - Pago con tarjeta de debito/credito (Visa/Master Card)'      
 WHEN @methodname='POD' AND @expectedMethod='amex' THEN 'POD - Tarjeta American Express'      
 WHEN @methodname='POD' AND @expectedMethod='falabella' THEN 'POD - Tarjeta Falabella'
 WHEN @methodname='POD' AND @expectedMethod='points' THEN 'POD - Pago con puntos'
 
 WHEN @methodname='PIS' THEN 'Pago en Tienda'      
 WHEN @methodname='CREDIT_CARD' THEN 'Tarjeta Credito/Debito'      
 WHEN @methodname='FALABELLA' THEN 'Falabella'      
 ELSE 'NONE'      
 END      
  
 --BUG 48474  
 -- FORMA DE PAGO SI EXISTEN MAS DE UNA  
 DECLARE @CONT VARCHAR(100);  
 DECLARE @METODO VARCHAR(100);  
  
 SELECT @CONT = isnull(count(*),0) FROM OrderFacts_POSMethodPayment WHERE UeNo=@UeNo  
  
 SELECT @METODO = B.PAGO  
 FROM OrderFacts_UE UE   
 LEFT JOIN (  
  SELECT POSM.UENO,  
  STRING_AGG(POSM.PaymentMethodDesc,',') PAGO   
  FROM dbo.OrderFacts_POSMethodPayment POSM  
  WHERE UENO = @UeNo  
  GROUP BY POSM.UeNo  
 ) B ON B.UENO = UE.UENO  
 WHERE UE.UENO = @UeNo  
      
-- ***********************************************************************************  
-- logica para HU_12513 - control de pedidos pendientes  
-- ***********************************************************************************  
  declare @EsEspecializada        bit = isnull((Select top (1) 1 from tms.RelacionTiendasEspecializadas r where r.StoreNumEspecializada = @StoreNum),0),  
    @ZonaHra  varchar(100) = (select ltrim(rtrim(n.UnPerm_Info)) from UnPerm_Info n where n.Id_Num_Un=@StoreNum and n.Id_Num_UnInfo=70);  
  declare @HoraZona datetime     = (getdate() at time zone 'UTC' at time zone @ZonaHra),  
    @cantidadHoras int=0,  
    @BitVencidaOriginal bit=0,  
    @BitVencidoCompromiso bit=0,  
    @fechaCompromiso datetime,  
    @Fec_Entrega datetime,  
    @DeliveryType varchar(20),  
    @CompromisoFecha date,  
    @CompromisoHora time(7),  
    @antesCobro bit = 0;  
    
  select top (1) @CompromisoFecha=c.OrderDeliveryDate, @CompromisoHora=c.OrderDeliveryTime   
  from OrderFacts_UE_Compromiso c   
  where c.OrderNo=@OrderNo and c.UeNo=@UeNo;  
  
  select top (1) @Fec_Entrega = dbo.fn_OMSGetDateJoined(u.OrderDeliveryDate, u.OrderDeliveryTime),  
  @DeliveryType= case  
     when u.DeliveryType = 'Entrega en tienda' then 'Recoge en tienda'  
     when u.DeliveryType in ('Entrega a domicilio','Envío a domicilio') then 'Entrega a Domicilio'  
     end,  
  @antesCobro = case when u.StatusUe IN (0,1,2) then 1 else 0 end  
  from OrderFacts_UE u   
  where u.UeNo=@UeNo;  
  
  
 set @cantidadHoras =   
 (select top (1) r.cantidadHoras   
  from RangoTiempoVencimiento r   
  join RangoTiempoVencimiento_FormaEntrega r2 on r.idRango=r2.idRango  
  join PrioridadSurtido_Cat_FormaEntrega t on t.Id=r2.idFormaEntrega  
where t.Descripcion = @DeliveryType  
  and (  
  (r.especializada=1 and @EsEspecializada=1)  
  or  
  (r.noEspecializada=1 and @EsEspecializada=0)  
  )  
  and r.activo=1);  
  
  
 -- se marcan las ordenes donde la fecha de la tienda  
 -- es mayor o igual a la fecha de entrega + 1 hora (para cubrir el slot de entrega)  
  
 set @BitVencidaOriginal =  
 case  
  when (@HoraZona >= (dateadd(HH,(@cantidadHoras + 1), @Fec_Entrega))) then 1  
  else 0  
 end  
  
 -- se marcan las ordenes cuya fecha compromiso, es mayor o igual a la fecha de la tienda;  
 -- y que son ordenes que aun estan antes del cobro.  
  
 set @BitVencidoCompromiso =  
 case   
  when (@HoraZona  
  >= (CONVERT(DATETIME,(CONVERT(VARCHAR(10),@CompromisoFecha) + 'T' + CONVERT(VARCHAR(12),@CompromisoHora))))) and @antesCobro=1 then 1  
  else 0  
 end  
  
 -- fecha compromiso  
 set @fechaCompromiso = (CONVERT(DATETIME,(CONVERT(VARCHAR(10),@CompromisoFecha) + 'T' + CONVERT(VARCHAR(12),@CompromisoHora))))  
  
 -- etiquetas y fechas cancelacion  
 declare @idAccionEtiqueta int,  
   @Descripcion      nvarchar(500),  
   @CancelaMotivo    varchar(80),  
   @CancelName       varchar(80),  
   @CancelaFecha     datetime;  
  
 select top (1) @idAccionEtiqueta=d.IdAccionEtiqueta, @Descripcion=d.NombreEtiqueta  
  from OrderFacts_UE_Compromiso c   
  join EtiqutasPedido d on d.IdEtiqueta=c.IdEtiqueta  
  where c.UeNo=@UeNo and c.OrderNo=@OrderNo;  
  
 select top (1) @CancelaMotivo=a.CancelCause, @CancelaFecha= dbo.fn_OMSGetDateJoined(a.CancelReqDate, a.CancelReqTime)  
 from OrderFacts_UE_Kardex_RMA a  
 where a.OrderNo=@OrderNo and a.UeNo=@UeNo;  
  
 ----------------PARAMETRO TIPOIDCANCELACION  
 select top (1)  @CancelName = tip.NombreCan   
 from OrderFacts_MotivoCanTda can  
 inner join OrderFacts_TipoCanTda tip on can.IdTipoCanTda = tip.IdTipoCanTda  
 where  can.NombreMotivo = @CancelaMotivo;  
  
  
 --------  
  
-- ***********************************************************************************  
-- ***********************************************************************************  
  
  
  
  -- ********************************************************************        
  -- DATOS DE LA ORDEN        
  -- ********************************************************************        
    select distinct  top 1      
      UE.[OrderNo]        
     ,UE.[CnscOrder]        
     ,UE.[StoreNum]        
     ,UE.[UeNo]        
     ,UE.[StatusUe]        
  ,FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.OrderDate, UE.OrderTime)),0)), 'dd/MMM/yyyy hh:mm tt')      
     as [OrderDate]        
  ,convert(time(7),dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.[OrderDate], UE.[OrderTime])),0)) AS [OrderTime]      
     ,FORMAT(CONVERT(DATETIME,(CONVERT(VARCHAR(10),UE.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12), UE.OrderDeliveryTime))), 'dd/MMM/yyyy hh:mm tt')        
     as [OrderDeliveryDate]        
     ,UE.[OrderDeliveryTime]        
     ,case         
    when ISNUMERIC(UE.[CreatedBy]) = 1 then apl.Desc_Apl        
    else UE.[CreatedBy]        
      end         AS [CreatedBy]          
     ,UE.[DeliveryType]        
     ,UE.[UeType]        
     ,UE.[IsPickingManual]        
     ,UE.[CustomerNo]        
     ,UE.[CustomerName]        
  -- bug.48319 - origen del telefono de cliente  
     --,isnull(ord.Phone,' ') as [Phone]    
  ,CASE WHEN NOT (json_value( replace(replace(replace(ext.ExtensionData,'[',''),']',''),'''','"'), '$.phone_home') IS NULL)  
    THEN json_value( replace(replace(replace(ext.ExtensionData,'[',''),']',''),'''','"'), '$.phone_home')   
    ELSE  
    CASE WHEN NOT (json_value( replace(replace(replace(ext.ExtensionData,'[',''),']',''),'''','"'), '$.phone_mobile') IS NULL)  
     THEN json_value( replace(replace(replace(ext.ExtensionData,'[',''),']',''),'''','"'), '$.phone_mobile')   
     ELSE UE.[Phone]  
    END  
   END  [Phone]  
  -- bug.48319 - origen del telefono de cliente  
     ,(ORD.Address1)        AS [Address1]        
     ,('Colonia: ' + ORD.Address2)     AS [Address2]     
     ,UE.[City]        
     ,isnull(ord.StateCode, ' ') as [StateCode]        
     ,UE.[PostalCode]        
     ,isnull(SHIP.ShipAddressReference,'')  AS [Reference]        
     ,UE.[NameReceives]        
     ,CASE         
    WHEN UE.[StatusUe] in (0,1,2,3,4,5) THEN ISNULL(CAST(TOT.TotalOrderNetPrice AS DECIMAL(18,2)),CAST(UE.[Total] AS DECIMAL(18,2)))        
    ELSE CAST(UE.[Total] AS DECIMAL(18,2))        
     END        
    as [Total]       
     ,UE.[NumPoints]        
     ,UE.[NumCashier]        
     ,UE.[NumPos]        
     ,UE.[TransactionId]        
     ,case         
     when @methodname = 'POD' then @methodnameSPA      
     when ISNUMERIC(UE.[CreatedBy]) = 1 and UE.[CreatedBy] <> '27' then fp.Desc_FormaPago -- ECOM - Descripcion larga del metodo de pago       
     when ISNUMERIC(UE.[CreatedBy]) = 1 and UE.[CreatedBy] = '27' then         
       ISNULL(MT.Desc_FormaPago, POSM.PaymentMethodDesc)    -- pedidos telefonicos        
     else     
   case when @CONT > 1 then @METODO else     -- BUG 48474  
   ISNULL(MT.Desc_FormaPago, POSM.PaymentMethodDesc)    -- SFCC - Descripción larga del metodo de pago    
   end  
 end           AS [MethodPayment]       
    ,UE.[CardNumber]        
     ,UE.[ShipperName]        
     ,CASE        
      WHEN UE.ShippingDate = '1900-01-01' THEN NULL        
   ELSE FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (UE.ShippingDate),0)), 'dd/MMM/yyyy hh:mm tt')      
      END as [ShippingDate]        
     ,UE.[TransactionNo]        
     ,ISNULL(convert(varchar,UE.[TrackingNo]),'') AS [TrackingNo]        
     ,ISNULL(UE.[NumBags],0)   AS [NumBags]        
     ,ISNULL(UE.[NumCoolers],0)  AS [NumCoolers]        
     ,ISNULL(UE.[NumContainers],0)  AS [NumContainers]        
     ,UE.[Terminal]        
     ,CASE        
      WHEN UE.DeliveryDate = '1900-01-01' THEN NULL            
  ELSE FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.DeliveryDate, UE.DeliveryTime)),0)), 'dd/MMM/yyyy hh:mm tt')      
      END as [DeliveryDate]        
   ,CASE      
   WHEN UE.DeliveryDate = '1900-01-01' THEN '00:00:00'      
   ELSE convert(time(7),dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.[DeliveryDate],UE.[DeliveryTime])),0))      
   END AS [DeliveryTime]      
     ,UE.[IdReceive]        
     ,UE.[NameReceive]        
     ,UE.[Comments]        
     ,UE.[Id_Supplier]        
     ,case  
  when not ordint.OrderNo is null and ordint.StatusUe=20  
   then 'Listo para recoger'  
  when UE.StatusUe = 11 then 'Devolucion Parcial'  
  when UE.StatusUe = 12 then 'Devolucion Total'  
  else STAT.OrderStatusDesc  
  end AS [StatusDescription]        
     ,SUP.[Name] AS [Supplier_Name]        
     ,CASE SHIP.ShippingMethod        
    WHEN 'Entrega en tienda' THEN 'Entrega en tienda'        
    ELSE RTRIM(LTRIM(ISNULL(SHIP.ShipAddressAddress1,' '))) + ', ' + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressAddress2,' ')))         
    + ', ' + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressCity,' '))) + ', ' + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressStateCode,' ')))         
    + ', '  + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressPostalCode,' ')))         
    + ', T:'  + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressPhone,' '))) + ', '  + RTRIM(LTRIM(ISNULL(SHIP.ShipAddressReference,' ')))         
      END        
      as [DeliveryAddress]        
     ,FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.PickingDateEnd, UE.PickingTimeEnd)),0)), 'dd/MMM/yyyy hh:mm tt') AS [PickingDate]      
   ,FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.PaymentDateEnd, UE.PaymentTimeEnd)),0)), 'dd/MMM/yyyy hh:mm tt') AS [PaymentDate]          
      ,STAT.OrderStatus  AS [OrderStatus]        
      ,ISNULL(CAST(STAT.CashPay AS DECIMAL(18,2)),0)  AS [CashPay]        
      ,ISNULL(CAST(STAT.VouchersPay AS DECIMAL(18,2)),0) AS [VouchersPay]        
      ,case         
   when ISNUMERIC(UE.[CreatedBy]) = 1 then  -- ECOM - Descripcion larga del metodo de pago        
    case when UE.[CreatedBy] <> '27' then STAT.MethodPaymentID      
    else FormaPago.Id_Num_FormaPago  -- Call Center - Descripcion larga del metodo de pago        
    end      
   WHEN @methodname='POD' AND @expectedMethod <> 'cash' THEN 0  
   else         
    ISNULL(MT.Id_Num_FormaPago, POSM.PaymentMethodId)    -- SFCC - Descripción larga del metodo de pago        
    end AS [MethodPaymentID]         
   ,FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.PackingDate, UE.PackingTime)),0)), 'dd/MMM/yyyy hh:mm tt') AS [PackingDate]      
   ,FORMAT((dbo.fn_GetTimeZoneByStore(UE.StoreNum, (dbo.fn_OMSGetDateJoined(UE.CarrierDate, UE.CarrierTime)),0)), 'dd/MMM/yyyy hh:mm tt') AS [CarrierDate]      
      ,ISNULL(PAY.CardNumber,'')                AS [Cuenta]        
      ,ISNULL(PAY.CardNumber,'')          AS [Cta]        
      ,ISNULL(        
    CASE        
     WHEN (PAY.ExpirationYear = 0 AND PAY.ExpirationMonth = 0) THEN ''        
     ELSE (RIGHT(CONVERT(VARCHAR(4),PAY.ExpirationYear),2) + CONVERT(VARCHAR(2),PAY.ExpirationMonth))        
    END,'')                AS [Vec]        
      ,ISNULL(PAY.CardType,'')           AS [Banco]        
      ,0                AS [Codigo_Autorizacion]        
      ,0                      AS [NumeroAfiliacion]        
      ,ISNULL(SHIP.ShipAddressFirstName,'')        AS [NomCteEnt]        
      ,ISNULL(RTRIM(LTRIM(STAT.FreightType)),'')                        AS [ShoppingCart]        
    ,ISNULL(FORMAT( dbo.fn_GetTimeZoneByStore(UE.StoreNum,       
    (dbo.fn_OMSGetSingleDateFormat((SELECT MIN(kar.OrderMovementDate) FROM OrderFacts_UE_Kardex kar WHERE kar.StoreNum = UE.StoreNum AND kar.OrderNo = UE.OrderNo AND kar.OrderMovementCode = 'A0002')))      
    ,0), 'dd/MMM/yyyy hh:mm tt'),'')      
                  AS [PickingDateStart]        
      ,CASE        
     -- ECOM        
     WHEN ISNUMERIC(UE.CreatedBy)=1 THEN CONVERT(VARCHAR, UE.OrderNo)        
     ELSE UE.UeNo        
    END                 AS [NroOrden]      
      ,@FlagLocal              AS [FlagLocal]      
      ,(select top 1 convert(varchar(4),u.id_num_un) + '.-' + U.Desc_UN + '(' + p.nom_poblacion +','+ e.Abrev_Estado + ')'  
     
    from UN AS U         
     INNER JOIN [Poblacion_d] as p           
     on u.Ids_Num_Poblacion = p.Ids_Num_Poblacion           
     inner join [Estado_d] as e           
     on p.Id_Num_Estado = e.Id_Num_Estado          
     where U.Id_Num_UN = UE.StoreNum)         AS [NomTienda],      
 ship.ShipAddressGeolocation          AS [Coordenadas],      
 [dbo].[fn_GetDeliveryOptionName](@OrderNo)       AS [DeliveryOptionName]  ,    
    sf.order_no OrderSF ,  
 ISNULL(FORMAT( dbo.fn_GetTimeZoneByStore(UE.StoreNum,       
    (dbo.fn_OMSGetSingleDateFormat((SELECT MIN(kar.OrderMovementDate) FROM OrderFacts_UE_Kardex kar WHERE kar.StoreNum = UE.StoreNum AND kar.OrderNo = UE.OrderNo AND kar.StatusUe = 0)))      
    ,0), 'dd/MMM/yyyy hh:mm tt'),'')  AS [ArriveDate],  
  
 case when ordint.Id_OrderFacts_Intertienda is null then '0' else '1' end IsOrderIntertienda,  
 case when ordint.StatusUe in (20,25) then '1' else '0' end statusRecibida  
 ,case when ordint.StatusUe = 25 then '1' else '0' end statusEntregada  
 ,(select dbo.fn_GetStoreNameByType (UE.OrderNo, 1)) [NameBase]  
    ,(select dbo.fn_GetStoreNameByType (UE.OrderNo, 2)) [NameNoEsp]  
  
 ,promotionId                       [promotionId]  
    ,cast(abs(price) as decimal(10,2)) [priceadj]  
  
 -- ***********************************************************************************  
 -- logica para HU_12513 - control de pedidos pendientes  
 -- ***********************************************************************************  
 ,@cantidadHoras        as [cantidadHoras]  
 ,@BitVencidaOriginal   as [BitVencidaOriginal]  
 ,@BitVencidoCompromiso as [BitVencidoCompromiso]  
 ,@fechaCompromiso      as [fechaCompromiso]  
 ,FORMAT(@fechaCompromiso, 'dd/MMM/yyyy hh:mm tt')  
                        as [commitmentDate]  
 ,@idAccionEtiqueta     as [idAccionEtiqueta]  
 ,@Descripcion          as [Descripcion]  
 ,@CancelaMotivo        as [CancelaMotivo]  
 ,@CancelaFecha         as [CancelaFecha]  
 ,@CancelName           as [CancelName]  
 -- ***********************************************************************************  
 --TASK 30396 Se agregan Fechas de recepcion y de entrega al cliente  
 ,FORMAT(CONVERT(DATETIME,(CONVERT(VARCHAR(10),ordint.ReciboDeliveryDate) + 'T' + CONVERT(VARCHAR(12), ordint.ReciboDeliveryTime))), 'dd/MMM/yyyy hh:mm tt') AS [FechaRecepcion]    
 ,FORMAT(CONVERT(DATETIME,(CONVERT(VARCHAR(10),ordint.EntregaDeliveryDate) + 'T' + CONVERT(VARCHAR(12), ordint.EntregaDeliveryTime))), 'dd/MMM/yyyy hh:mm tt') AS [FechaEntrega]    
 , ISNULL((SELECT TOP 1 1 FROM Orderfacts_UE_DataAcuseRecibo DR where DR.UeNo = @UeNo), 0 ) AS TienePDF  
 ,UE.EstatusApp   
 ,UE.ConfirmationNumber  
 ,UE.formaEntrega  
  ,ttl.EsNacional 
  
    from [dbo].[OrderFacts_UE] UE        
 inner join OrderFacts_UE_StatusCodes           on UE.StatusUe = OrderFacts_UE_StatusCodes.StatusUe        
 left join dbo.apl                              on apl.Id_Num_Apl = CONVERT(INT, case when isnumeric(UE.CreatedBy) = 1 then UE.CreatedBy else '24' end)        
 left join dbo.OrderFacts_POSMethodPayment POSM on POSM.OrderNo = UE.OrderNo        
 left join dbo.OrderFacts_POSOrderStatus STAT   on STAT.OrderNo = UE.OrderNo        
 left join dbo.FormaPago fp                     on fp.Id_Num_FormaPago = STAT.MethodPaymentID        
 left join dbo.OrderFacts_Supplier SUP          on SUP.Id_Supplier = UE.[Id_Supplier] AND SUP.Id_Num_UN = UE.StoreNum       
 -- localizar el shipment de la consignacion - inicio      
 left join dbo.OrderFacts_Order ORD             on ORD.OrderNo = UE.OrderNo  
 left join dbo.OrderFacts_Intertienda ordint    on ORD.OrderNo = ordint.OrderNo  
 left join dbo.OrderFacts_OrderPayments PAY     on PAY.CnscOrder = ORD.CnscOrder        
 left join dbo.OrderFacts_OrderShipments SHIP   on SHIP.CnscOrder = ORD.CnscOrder         
      and ship.ShipmentId = (select top 1 q.ProdItemShipmentId from dbo.OrderFacts_OrderProducts q where         
    q.CnscOrder = (select top 1 CnscOrder from dbo.OrderFacts_OrderProducts q where CnscOrder in (select top 1 CnscOrder from OrderFacts_Order where OrderNo=@OrderNo))        
   and             
    q.ProdItemBarcode = (select top 1 p.Barcode from dbo.OrderFacts_UE_ItemsToSupply p where p.OrderNo = @OrderNo and not p.Barcode in (select distinct c.BarCode from dbo.OrderFacts_CarrierCodes c) ))        
   -- localizar el shipment de la consignacion - final      
 left join dbo.OrderFacts_OrderTotals TOT       on TOT.CnscOrder = ORD.CnscOrder        
 left join dbo.TYC_OrdersComments ORDCOM        on ORDCOM.CnscOrder = ORD.CnscOrder        
 LEFT JOIN dbo.OrderFacts_methodPayment MT      on MT.PaymentMethodDesc = POSM.PaymentMethodDesc        
 -- Call Center      
 LEFT join Carrito.OrdenPago OrdenPago (NOLOCK) ON    -- MODIFICADO            
  OrdenPago.ID_Num_Orden = @OrderId      
 LEFT join Carrito.FormaPagoCte_d FormaPagoCte_d (NOLOCK) on  -- MODIFICADO            
   OrdenPago.Id_Num_Cte = FormaPagoCte_d.Id_Num_Cte            
  and OrdenPago.Id_Cnsc_FormaPagoCte_d = FormaPagoCte_d.Id_Cnsc_FormaPagoCte_d             
 LEFT join Carrito.FormaPago FormaPago (NOLOCK) on      -- MODIFICADO            
  FormaPagoCte_d.ID_Num_FormaPago = FormaPago.ID_Num_FormaPago       
 -- Call Center      
 left join OrderFacts_UE_Transition t on t.OrderNo = UE.OrderNo  
 left join tbl_Descarga_Order_SF sf on convert(int,sf.order_no)=t.OrderNoPOS     
  
 -- HU.12521.visibilidad.de.cupones  
    left join OrderFacts_UE_PriceAdjOrder pa on pa.OrderNo = ue.OrderNo and pa.UeNo = ue.UeNo and pa.ItemCnsc=1  
 -- HU.12521.visibilidad.de.cupones  
   -- BUG 48319  
 LEFT JOIN OrderFacts_JsonExtension ext on ext.OrderNo = UE.OrderNo  
  LEFT JOIN OrderFacts_UE_ShipmentTracking uest ON uest.OrderNo = UE.OrderNo
 LEFT JOIN tms.TransportistaTipoLogistica ttl ON ttl.IdTransportista = uest.IdTransportista AND ttl.IdTipoLogistica = uest.IdTipoLogistica
  
  
    where UE.OrderNo = @OrderNo and UE.UeNo = @UeNo;        
      
   
  -- ********************************************************************        
  -- PRODUCTOS A SURTIR - hecho por Julius        
  -- ********************************************************************        
    select * from [dbo].[OrderFacts_UE_ItemsToSupply] ue        
    where ue.OrderNo = @OrderNo   
 and UE.CnscOrder = @cnscOrder        
 -- HU.40510 no devolver productos de garantias  
 and not ue.Barcode in (select distinct x.WarrantyBarcode from OrderFacts_OrderOptionProducts x where x.OrderNo = ue.OrderNo);  
        
   -- ********************************************************************        
  -- PRODUCTOS SURTIDOS        
  -- ********************************************************************        
    select * from [dbo].[OrderFacts_UE_ItemsSupplied] where @OrderNo = OrderNo AND CnscOrder = @cnscOrder        
        
  -- ********************************************************************        
  -- DATOS DEL KARDEX        
  -- ********************************************************************        
    select top 1 * from [dbo].[OrderFacts_UE_Kardex] where UeNo = @UeNo and OrderNo = @OrderNo order by OrderMovementDate desc        
        
  -- ********************************************************************        
  -- ARTICULOS PEDIDOS, SURTIDOS, COBRADOS        
  -- ********************************************************************        
   IF OBJECT_ID('tempdb.dbo.#T', 'U') IS NOT NULL        
    DROP TABLE #T;        
   IF OBJECT_ID('tempdb.dbo.#FIN', 'U') IS NOT NULL        
    DROP TABLE #FIN;        
        
   CREATE TABLE #T        
   (        
    OrderNo      INT        
      ,CnscOrder     BIGINT        
      ,ItemCnsc     SMALLINT        
      ,ProductId     INT        
      ,Barcode      BIGINT        
      ,ProductName     VARCHAR(175)        
      ,e_Quantity        DECIMAL(18,2)        
      ,c_Quantity     DECIMAL(18,2)        
      ,e_tot         DECIMAL(18,2)        
      ,c_tot      DECIMAL(18,2)        
      ,pe_price        DECIMAL(18,2)        
      ,pe_Quantity     DECIMAL(18,2)        
      ,e_price      DECIMAL(18,2)        
      ,pe_tot      DECIMAL(18,2)        
    ,Id_Cnsc_ArtCar_Obser  INT        
      ,Desc_ArtCarObser   VARCHAR(255)        
      ,Observacion     VARCHAR(255)        
      ,UnitMeasure     VARCHAR(10)        
      ,Supplied     TINYINT        
      ,c_price      DECIMAL(18,2)        
      ,flete      VARCHAR(2)        
      ,PosObservDesc    VARCHAR(255)        
      ,pe_offer     DECIMAL(18,2)        
      ,e_offer      DECIMAL(18,2)        
   );        
   CREATE NONCLUSTERED INDEX ix_tempT ON #T (OrderNo,CnscOrder,ProductId,Barcode);        
        
   CREATE TABLE #FIN        
   (        
    OrderNo      INT        
      ,CnscOrder     BIGINT        
      ,ItemCnsc     SMALLINT        
      ,ProductId     INT        
      ,Barcode      BIGINT        
      ,ProductName     VARCHAR(175)        
      ,e_Quantity        DECIMAL(18,2)        
      ,c_Quantity     DECIMAL(18,2)        
      ,e_tot         DECIMAL(18,2)        
      ,c_tot      DECIMAL(18,2)        
      ,pe_price        DECIMAL(18,2)        
      ,pe_Quantity     DECIMAL(18,2)        
      ,e_price DECIMAL(18,2)        
      ,pe_tot      DECIMAL(18,2)        
      ,Id_Cnsc_ArtCar_Obser  INT        
      ,Desc_ArtCarObser   VARCHAR(255)        
      ,Observacion     VARCHAR(255)        
      ,UnitMeasure     VARCHAR(10)        
      ,Supplied     TINYINT        
      ,c_price      DECIMAL(18,2)      
      ,flete      VARCHAR(2)        
      ,PosObservDesc    VARCHAR(255)        
      ,pe_offer     DECIMAL(18,2)        
      ,e_offer      DECIMAL(18,2)        
   );        
   CREATE NONCLUSTERED INDEX ix_tempFIN ON #FIN (OrderNo,CnscOrder,ProductId,Barcode);        
        
  -- ************************************************************************************************        
  -- ARTICULOS SOLICITADOS - DATASET #5        
  -- ************************************************************************************************        
 if @CreatedBy = '27'      
 begin      
  INSERT INTO #T        
  SELECT         
       pe.OrderNo            
   ,pe.CnscOrder        
   ,0                as ItemCnsc            
   ,ISNULL((SELECT TOP 1 c.ProductId FROM OrderFacts_CarrierCodes c WHERE c.BarCode = pe.PosBarcode),        
       ISNULL((SELECT TOP 1 it.ProductId FROM dbo.OrderFacts_UE_ItemsToSupply it WHERE it.Barcode = pe.PosBarcode),0))        
         as ProductId            
   ,pe.PosBarcode            
   ,ISNULL( pe.PosProductDescription ,(SELECT TOP 1 SUBSTRING(Art.Desc_Art,1,175) FROM Art WHERE Art.Num_CodBarra = pe.PosBarcode))        
         as ProductName        
   ,0                as e_Quantity            
   ,0                as c_Quantity        
   ,0                as e_tot            
   ,0                as c_tot        
   ,isnull(CAST(pe.PosPriceOfferSale AS DECIMAL(18,2)),0)   as pe_price           
   ,case       
   when it.Quantity is null then 0      
   else ISNULL(CAST(pe.PosQuantity AS DECIMAL(18,2)),0)       
    end      as pe_Quantity           
   ,0                as e_price           
   ,ISNULL(CAST((pe.PosQuantity * pe.PosPriceOfferSale) AS DECIMAL(18,2)),0)        
            as pe_tot            
   ,''               as Id_Cnsc_ArtCar_Obser        
   ,''               as Desc_ArtCarObser        
   ,''               as Observacion        
   ,ISNULL((SELECT TOP 1 UnidadMedida FROM Art WHERE Art.Num_CodBarra = pe.PosBarcode), it.UnitMeasure)        
            as UnitMeasure        
   ,0                as supplied        
   ,0                as c_price        
   ,'NO'             as flete        
   ,''               as PosObservDesc        
   ,CAST(ISNULL((pe.PosQuantity * pe.PosPriceOfferSale),0) AS DECIMAL(18,2))        
            as pe_offer        
   ,0                as e_offer      
  FROM [dbo].[OrderFacts_POSProducts] AS pe      
  left join [dbo].[OrderFacts_UE_ItemsToSupply]  as it on it.OrderNo=pe.OrderNo and it.Barcode=pe.PosBarcode      
  WHERE pe.OrderNo = @OrderNo        
  AND pe.CnscOrder = @cnscOrderOrd -- Productos de la orden.        
      
  -- *******************************************************************************************      
  -- *******************************************************************************************      
  INSERT INTO #T        
  SELECT         
    so.Id_Num_Orden      
   ,ord.CnscOrder      
   ,0               as ItemCnsc            
   ,pe.Id_Num_Sku            as ProductId      
   ,prd.ProdItemBarcode          as Barcode      
   ,prd.ProdItemProductName         as ProductName            
   ,0               as e_Quantity      
   ,0               as c_Quantity      
   ,0               as e_tot      
   ,0               as c_tot      
   -- MOD - 24/11/2024 - BUG 51311 error en consulta del detalle de orden "pedidos telefonicos"  
   ,case   
  when prd.ProdItemQuantity > 0 then  
  ISNULL(CAST((prd.ProdItemGrossPrice / prd.ProdItemQuantity) AS DECIMAL(18,2)),0)      
  else 0  
 end             as pe_price           
   ,ISNULL(CAST(prd.ProdItemQuantity AS DECIMAL(18,2)),0)  as pe_Quantity           
   ,0               as e_price           
   ,ISNULL(CAST(prd.ProdItemGrossPrice AS DECIMAL(18,2)),0)       
                 as pe_tot            
   ,''              as Id_Cnsc_ArtCar_Obser        
   ,''        as Desc_ArtCarObser        
   ,''              as Observacion        
   ,prd.ProdItemUnit           as UnitMeasure        
   ,0               as supplied        
   ,0               as c_price        
   ,'NO'              as flete        
   ,''              as PosObservDesc        
   -- MOD - 24/11/2024 - BUG 51311 error en consulta del detalle de orden "pedidos telefonicos"  
   ,case   
  when prd.ProdItemQuantity > 0 then  
  ISNULL(CAST((prd.ProdItemGrossPrice / prd.ProdItemQuantity) AS DECIMAL(18,2)),0)      
  else 0  
    end             as pe_offer        
   ,0               as e_offer        
  FROM [dbo].[SOT_OrderFulfillment_d]  as pe        
  LEFT JOIN dbo.SOT_OrderFulfillment so on so.Id_Cnsc_SOTMessage = pe.Id_Cnsc_SOTMessage      
  LEFT JOIN dbo.OrderFacts_Order ord on ord.OrderNo = so.Id_Num_Orden      
  LEFT JOIN dbo.OrderFacts_OrderProducts prd on prd.CnscOrder = ord.CnscOrder and prd.ProdItemBarcode=pe.Id_Num_CodBarra and prd.ProdItemProductId=pe.Id_Num_Sku      
  WHERE so.Id_Num_Orden = @OrderNo      
  and ((pe.Num_SkuSustituto > 0 and not pe.Num_SkuSustituto is null)      
  or pe.Cant_Surtida = 0);      
      
  -- *******************************************************************************************      
  -- *******************************************************************************************      
 end      
 else      
 begin      
  INSERT INTO #T        
  SELECT         
    pe.OrderNo            
   ,pe.CnscOrder          
   ,pe.ItemCnsc            
   ,pe.ProductId            
   ,pe.Barcode            
   ,pe.ProductName            
   ,0                as e_Quantity            
   ,0                as c_Quantity        
   ,0                as e_tot            
   ,0                as c_tot        
    ,ISNULL(CAST(        
  CASE WHEN pe.Quantity > 0      
   THEN (SELECT TOP 1 (op.ProdItemGrossPrice/op.ProdItemQuantity) FROM dbo.OrderFacts_OrderProducts op WHERE op.CnscOrder=ord.CnscOrder and op.ProdItemBarcode=pe.Barcode)    
   ELSE 0 END        
   AS DECIMAL(18,2)),0)        
    as pe_price           
   ,ISNULL(CAST(pe.Quantity AS DECIMAL(18,2)),0)     as pe_Quantity           
   ,0                as e_price           
   ,ISNULL(CAST((pe.Price) AS DECIMAL(18,2)),0)      as pe_tot            
   -- * pe.Price        
   ,''                as Id_Cnsc_ArtCar_Obser        
   ,''                as Desc_ArtCarObser        
   ,''                as Observacion        
   ,pe.UnitMeasure             as UnitMeasure        
   ,0                as supplied        
   ,0                as c_price        
   ,'NO'               as flete        
   ,''                as PosObservDesc        
   ,CAST(ISNULL((pos.PosQuantity * pos.PosPriceOfferSale), 0) AS decimal(18,2))        
        as pe_offer        
   ,0                as e_offer        
  FROM [dbo].[OrderFacts_UE_ItemsToSupply]  as pe        
  LEFT JOIN dbo.OrderFacts_POSProducts pos ON pos.OrderNo = pe.OrderNo AND pos.PosBarcode = pe.Barcode        
  left join dbo.OrderFacts_Order ord on ord.orderno = pe.orderno      
      
  WHERE pe.OrderNo = @OrderNo and pe.CnscOrder = @cnscOrder;        
   -- ************************************************************************************************        
  INSERT INTO #T        
  SELECT         
       pe.OrderNo            
   ,pe.CnscOrder        
   ,0                as ItemCnsc            
   ,ISNULL((SELECT TOP 1 c.ProductId FROM OrderFacts_CarrierCodes c WHERE c.BarCode = pe.PosBarcode),        
    ISNULL((SELECT TOP 1 Art.Id_Num_SKU FROM Art WHERE Art.Num_CodBarra = pe.PosBarcode),0))        
        as ProductId            
   ,pe.PosBarcode            
   ,ISNULL( pe.PosProductDescription ,(SELECT TOP 1 SUBSTRING(Art.Desc_Art,1,175) FROM Art WHERE Art.Num_CodBarra = pe.PosBarcode))        
        as ProductName        
   ,0                as e_Quantity            
  ,0                as c_Quantity        
   ,0                as e_tot            
   ,0                as c_tot        
   ,isnull(CAST(pe.PosPriceNormalSale AS DECIMAL(18,2)),0)   as pe_price           
   ,ISNULL(CAST(pe.PosQuantity AS DECIMAL(18,2)),0)     as pe_Quantity           
   ,0                as e_price           
   ,ISNULL(CAST((pe.PosQuantity * pe.PosPriceNormalSale) AS DECIMAL(18,2)),0)        
        as pe_tot            
   ,''                as Id_Cnsc_ArtCar_Obser        
   ,''                as Desc_ArtCarObser        
   ,''                as Observacion        
   ,ISNULL((SELECT TOP 1 UnidadMedida FROM Art WHERE Art.Num_CodBarra = pe.PosBarcode), NULL)        
        as UnitMeasure        
   ,0                as supplied        
   ,0                as c_price        
   ,'NO'               as flete        
   ,''                as PosObservDesc        
   ,CAST(ISNULL((pe.PosQuantity * pe.PosPriceOfferSale),0) AS DECIMAL(18,2))        
        as pe_offer        
   ,0                as e_offer        
  FROM [dbo].[OrderFacts_POSProducts] AS pe        
  WHERE pe.OrderNo = @OrderNo        
  AND pe.CnscOrder = @cnscOrderOrd -- Productos de la orden.        
  -- SOLO Incluir el barcode de Fletes        
  AND pe.PosBarcode IN (SELECT distinct BarCode FROM OrderFacts_CarrierCodes)        
 end      
       
  -- ************************************************************************************************        
  -- ARTICULOS SURTIDOS - DATASET #5        
  -- ************************************************************************************************        
  -- ORIGINAL V2.0        
    INSERT INTO #T        
    SELECT e.OrderNo            
     ,e.CnscOrder        
     ,0                as ItemCnsc            
     ,ISNULL((SELECT TOP 1 Art.Id_Num_SKU FROM Art WHERE Art.Num_CodBarra = e.PosBarcode),0)        
                   as ProductId            
     ,e.PosBarcode             as Barcode        
     ,ISNULL(e.PosProductDescription, (SELECT TOP 1 SUBSTRING(Art.Desc_Art,1,175) FROM Art WHERE Art.Num_CodBarra = e.PosBarcode))        
                   as ProductName        
     ,ISNULL(CAST(e.PosQuantity AS DECIMAL(18,2)),0)     as e_Quantity            
     ,0                as c_Quantity        
     ,ISNULL(CAST((e.PosQuantity * (CASE WHEN e.PosPriceOfferSale > 0 THEN e.PosPriceOfferSale ELSE e.PosPriceNormalSale END)) AS DECIMAL(18,2)),0)        
                   as e_tot            
     ,0                as c_tot        
     ,0                as pe_price           
     ,0                as pe_Quantity           
     ,isnull(CAST((CASE WHEN e.PosPriceOfferSale > 0 THEN e.PosPriceOfferSale ELSE e.PosPriceNormalSale END) AS DECIMAL(18,2)),0)        
                   as e_price           
     ,0                as pe_tot            
     ,0                as Id_Cnsc_ArtCar_Obser        
     ,''                as Desc_ArtCarObser        
     ,''                as Observacion        
     ,ISNULL((SELECT TOP 1 UnidadMedida FROM Art WHERE Art.Num_CodBarra = e.PosBarcode), NULL)        
                   as UnitMeasure        
     ,0                as supplied        
     ,0                as c_price        
     ,'NO'               as flete        
     ,''                as PosObservDesc        
     ,0                as pe_offer        
     ,CAST(ISNULL((e.PosQuantity * e.PosPriceOfferSale),0) AS decimal(18,2))        
                   as e_offer        
    FROM [dbo].[OrderFacts_POSProducts] AS e        
    WHERE e.OrderNo = @OrderNo    -- Productos de la orden.        
   AND (        
 e.PosBitProductSupplied = 1   -- Productos surtidos.        
    OR         
    e.PosBarcode IN (SELECT distinct BarCode FROM OrderFacts_CarrierCodes) AND @IsPickingManual = 0        
    )        
        
  -- ************************************************************************************************        
  -- ARTICULOS COBRADOS - DATASET #5        
  -- ************************************************************************************************        
    INSERT INTO #T        
    SELECT        
    POS.OrderNo            
   ,POS.CnscOrder        
   ,0                      as ItemCnsc        
   ,ISNULL((SELECT TOP 1 Art.Id_Num_SKU FROM Art WHERE Art.Num_CodBarra = POS.PosBarcode),        
    ISNULL((SELECT TOP 1 o.ProdItemProductId FROM OrderFacts_OrderProducts o WHERE o.CnscOrder = POS.CnscOrder and o.ProdItemBarcode = POS.PosBarcode),0))        
                         as ProductId            
   ,POS.PosBarcode                   as Barcode            
   ,ISNULL((SELECT TOP 1 SUBSTRING(Art.Desc_Art,1,175) FROM Art WHERE Art.Num_CodBarra = POS.PosBarcode),        
    ISNULL(POSP.PosProductDescription,        
    ISNULL((SELECT TOP 1 o.ProdItemProductName FROM OrderFacts_OrderProducts o WHERE o.CnscOrder = POS.CnscOrder and o.ProdItemBarcode = POS.PosBarcode),'')))        
                         as ProductName        
   ,0                      as e_Quantity            
   ,isnull(CAST(POS.OrderQuantityPerItem AS DECIMAL(18,3)),0)        as c_Quantity        
   ,0                      as e_tot            
   ,ISNULL(CAST((POS.OrderQuantityPerItem * POS.OrderPricePerItem) AS DECIMAL(18,2)),0) as c_tot        
   ,0                      as pe_price           
   ,0                      as pe_Quantity           
   ,0                      as e_price           
   ,0                    as pe_tot            
   ,0                      as Id_Cnsc_ArtCar_Obser        
   ,''                      as Desc_ArtCarObser        
   ,''                      as Observacion        
   ,ISNULL((SELECT TOP 1 UnidadMedida FROM Art WHERE Art.Num_CodBarra = POS.PosBarcode), NULL)        
                         as UnitMeasure        
   ,0                      as supplied        
   ,isnull(CAST(POS.OrderPricePerItem AS DECIMAL(18,2)),0)         as c_price        
   ,'NO'                     as flete        
   ,''                      as PosObservDesc        
   ,0                      as pe_offer        
   ,0                      as e_offer        
   FROM OrderFacts_POSOrderSupplyDetail POS        
    LEFT JOIN OrderFacts_POSProducts POSP on POSP.CnscOrder = POS.CnscOrder and POS.PosBarcode = POSP.PosBarcode        
 LEFT JOIN OrderFacts_OrderOptionProducts OPT on OPT.WarrantyBarcode = POS.PosBarcode  
    WHERE POS.OrderNo = @OrderNo  
 and OPT.WarrantyBarcode IS NULL;  
        
  -- ************************************************************************************************        
  -- GROUPING DATA SET temporal        
  -- ************************************************************************************************        
    INSERT INTO #FIN        
    SELECT        
    OrderNo        
      ,MAX(CnscOrder)    AS CnscOrder        
      ,MAX(ItemCnsc)    AS ItemCnsc        
      ,MAX(ProductId)    AS ProductId        
      ,Barcode        
      ,LTRIM(RTRIM(MAX(ProductName))) AS ProductName        
      ,SUM(e_Quantity)    AS e_Quantity        
      ,SUM(c_Quantity)    AS c_Quantity        
      ,SUM(e_tot)     AS e_tot        
      ,SUM(c_tot)     AS c_tot        
      ,SUM(pe_price)    AS pe_price        
      ,SUM(pe_Quantity)   AS pe_Quantity        
      ,SUM(e_price)    AS e_price        
      ,SUM(pe_tot)     AS pe_tot        
      ,MAX(Id_Cnsc_ArtCar_Obser) AS Id_Cnsc_ArtCar_Obser        
      ,LTRIM(RTRIM(MAX(Desc_ArtCarObser)))  AS Desc_ArtCarObser        
      ,LTRIM(RTRIM(MAX(Observacion)))   AS Observacion        
      ,MAX(UnitMeasure)   AS UnitMeasure        
      ,0       AS Supplied        
      ,SUM(c_price)    AS c_price        
      ,MAX(flete)     AS flete        
      ,MAX(PosObservDesc)   AS PosObservDesc        
      ,SUM(pe_offer)    AS pe_offer        
      ,SUM(e_offer)    AS e_offer        
    FROM #T        
    GROUP BY OrderNo, Barcode        
          
    UPDATE #FIN        
   SET Supplied = 1        
   WHERE e_Quantity > 0 or c_Quantity > 0        
        
    UPDATE #FIN        
    SET PosObservDesc = RTRIM(ISNULL(prod.PosObservDesc,''))        
    FROM #FIN F        
    LEFT JOIN OrderFacts_POSProducts prod on prod.OrderNo = F.OrderNo and prod.PosBarcode = F.Barcode        
      
    -- La orden en estado "en despacho" muestra el flete en seccion "surtido", y toma las cantidades del PEDIDO.        
 IF @Orderstatus >= 3  AND @IsPickingManual = 0   
    BEGIN        
   UPDATE #FIN        
      -- FIX - 16/10/2023 - Mantener el valor de lo surtido por picking app  
   --SET e_Quantity = pe_Quantity,        
   -- e_price = pe_price,        
   -- e_tot = pe_tot,        
   SET  
    flete = 'SI',        
    Supplied = 1        
   WHERE #FIN.Barcode IN (SELECT BarCode FROM OrderFacts_CarrierCodes);        
    END        
    -- en caso contrario solo lo habilita para agrupar en la seccion "surtido".        
 ELSE   
    IF @Orderstatus >= 4 AND @IsPickingManual = 1        
   BEGIN        
    UPDATE #FIN        
     SET         
     e_Quantity = pe_Quantity,        
     e_price = pe_price,        
     e_tot = pe_tot,        
     flete = 'SI',        
     Supplied = 1        
     WHERE #FIN.Barcode IN (SELECT BarCode FROM OrderFacts_CarrierCodes)        
   END        
        
    -- las ordenes en estado cobrado, o posteriores siempre agrupan en "surtido" y toman las cantidades del PEDIDO.        
 -- para los productos flete  
 IF (@Orderstatus >= 4)   
  BEGIN        
   UPDATE #FIN        
   SET c_Quantity = pe_Quantity,        
    c_price = pe_price,        
    c_tot = pe_tot,      
    flete = 'SI',        
    Supplied = 1        
   WHERE #FIN.Barcode IN (SELECT BarCode FROM OrderFacts_CarrierCodes)        
   AND #FIN.c_Quantity =0        
  END        
  
   -- Si un producto esta en gramaje, pero el cliente pidio píezas; se debe hacer la conversion en la muestra de PIEZAS        
   -- A. Para Piezas pedidas esto aplica en todos los estados de la orden.        
     UPDATE #FIN        
  SET         
  pe_Quantity =         
  CASE         
   WHEN ISNULL(PAD.ReqQuantity,0) > 0 AND ISNULL(PAD.ReqQuantity,0) <> FN.pe_Quantity  AND (PAD.BaseUnitMeasure <> PAD.ReqUnitMeasure) THEN FORMAT(ISNULL(PAD.ReqQuantity,0),'#####0.###')        
   ELSE FORMAT(FN.pe_Quantity,'#####0.###')        
  END        
  FROM #FIN FN        
  LEFT JOIN dbo.OrderFacts_ProductsAddons PAD on PAD.OrderNo = FN.OrderNo AND PAD.PosBarcode = FN.Barcode and PAD.[ModifiedByUser] = 0        
  
   -- B. Para piezas surtidas esto aplica una vez que la orden se encuentra en estado 3 o posterior.        
   IF (@Orderstatus >= 3) -- las ordenes en estado cobrado, o posteriores siempre agrupan en "surtido" y toman las cantidades del PEDIDO.        
    BEGIN        
      UPDATE #FIN        
     SET         
     e_Quantity =         
     CASE WHEN ISNULL(PRD.PosBitProductSupplied,0) = 1 THEN        
      CASE         
       WHEN ISNULL(PAD.ReqQuantity,0) > 0 AND ISNULL(PAD.ReqQuantity,0) <> e_Quantity AND (PAD.BaseUnitMeasure <> PAD.ReqUnitMeasure) THEN FORMAT(ISNULL(PAD.ReqQuantity,0),'#####0.###')        
       ELSE FORMAT(FN.e_Quantity,'#####0.###')        
      END        
     ELSE FORMAT(FN.e_Quantity,'#####0.###')        
     END        
     FROM #FIN FN        
     LEFT JOIN dbo.OrderFacts_ProductsAddons PAD on PAD.OrderNo = FN.OrderNo AND PAD.PosBarcode = FN.Barcode and PAD.[ModifiedByUser] = 0        
     LEFT JOIN dbo.OrderFacts_POSProducts PRD on PRD.OrderNo = FN.OrderNo and PRD.PosBarcode = FN.Barcode        
    END        
     
   -- C: Para piezas cobradas esto aplica una vez que la orden se encuentra en estado 4 o posterior.        
   IF (@Orderstatus >= 4) -- las ordenes en estado cobrado, o posteriores siempre agrupan en "surtido" y toman las cantidades del PEDIDO.        
    BEGIN        
        
      UPDATE #FIN        
     SET         
     c_Quantity =         
     CASE WHEN ISNULL(PRD.PosBitProductSupplied,0) = 1 THEN        
      CASE         
       WHEN ISNULL(PAD.ReqQuantity,0) > 0 AND ISNULL(PAD.ReqQuantity,0) <> FN.c_Quantity AND (PAD.BaseUnitMeasure <> PAD.ReqUnitMeasure)  THEN FORMAT(ISNULL(PAD.ReqQuantity,0),'#####0.###')        
       ELSE FORMAT(FN.c_Quantity,'#####0.###')        
      END        
     ELSE FORMAT(FN.c_Quantity,'#####0.###')        
     END        
     FROM #FIN FN        
     LEFT JOIN dbo.OrderFacts_ProductsAddons PAD on PAD.OrderNo = FN.OrderNo AND PAD.PosBarcode = FN.Barcode and PAD.[ModifiedByUser] = 0        
     LEFT JOIN dbo.OrderFacts_POSProducts PRD on PRD.OrderNo = FN.OrderNo and PRD.PosBarcode = FN.Barcode        
    END        
     
   -- D: ultima revision de cantidades surtidas, si aun estan en cero y ya se cobro; reciben la cantidad cobrada.        
   IF @Orderstatus >= 4        
    BEGIN        
      UPDATE #FIN        
     SET         
      e_Quantity = c_Quantity,        
      e_price = c_price,        
      e_tot = c_tot        
     WHERE NOT #FIN.Barcode IN (SELECT BarCode FROM OrderFacts_CarrierCodes)        
     AND #FIN.Supplied = 1  
  ANd #FIN.e_Quantity = 0  
  -- FIX - 16/10/2023 - Mantener el valor de lo surtido por picking app  
    END        
  
   -- E: Limpiar productos que quedan en cero en todos sus indicadores.        
   DELETE FROM #FIN WHERE e_Quantity=0 AND c_Quantity = 0 AND pe_Quantity = 0;        
        
        
  -- ************************************************************************************************        
  -- ARTICULOS SURTIDOS - DATASET #5        
  -- ************************************************************************************************        
    SELECT        
    #FIN.OrderNo        
      ,#FIN.CnscOrder     AS CnscOrder        
      ,#FIN.ItemCnsc     AS ItemCnsc        
      ,#FIN.ProductId     AS ProductId        
      ,#FIN.Barcode     AS Barcode        
      ,#FIN.ProductName    AS ProductName        
      ,#FIN.e_Quantity     AS e_Quantity        
      ,#FIN.c_Quantity     AS c_Quantity        
      ,#FIN.e_tot      AS e_tot        
      ,#FIN.c_tot      AS c_tot        
      ,#FIN.pe_price     AS pe_price        
      ,#FIN.pe_Quantity    AS pe_Quantity    -- CANTIDAD SOLICITADA        
      ,#FIN.e_price     AS e_price        
      ,#FIN.pe_tot      AS pe_tot        
      ,#FIN.Id_Cnsc_ArtCar_Obser  AS Id_Cnsc_ArtCar_Obser        
      ,#FIN.Desc_ArtCarObser   AS Desc_ArtCarObser        
      ,#FIN.Observacion    AS Observacion        
      ,#FIN.UnitMeasure    AS UnitMeasure        
      ,#FIN.Supplied     AS Supplied        
      ,#FIN.c_price     AS c_price        
      ,#FIN.PosObservDesc    AS PosObservDesc        
      ,ue.UeNo       AS UeNo        
    FROM #FIN        
    LEFT JOIN OrderFacts_UE ue on ue.OrderNo = #FIN.OrderNo        
    WHERE Supplied = 1        
 -- HU.40510 no devolver productos de garantias  
 and not #FIN.Barcode in (select distinct x.WarrantyBarcode from OrderFacts_OrderOptionProducts x where x.OrderNo = ue.OrderNo)  
  
    ORDER BY PosObservDesc, ProductName        
        
  -- ********************************************************************        
  -- ARTICULOS NO SURTIDOS - DATA SET #6        
  -- ********************************************************************        
    SELECT        
    #FIN.OrderNo    AS OrderNo        
      ,#FIN.CnscOrder    AS CnscOrder        
      ,#FIN.ItemCnsc    AS ItemCnsc        
      ,#FIN.ProductId    AS ProductId        
      ,#FIN.Barcode    AS Barcode        
      ,#FIN.ProductName   AS ProductName        
      ,#FIN.e_Quantity    AS e_Quantity        
      ,#FIN.c_Quantity    AS c_Quantity        
      ,#FIN.e_tot     AS e_tot        
      ,#FIN.c_tot     AS c_tot        
      ,#FIN.e_price    AS e_price          
      ,#FIN.Observacion   AS Observations        
      ,#FIN.UnitMeasure   AS UnitMeasure        
      ,#FIN.OrderNo    AS OrderNo2        
      ,#FIN.CnscOrder    AS CnscOrder2        
      ,#FIN.ItemCnsc    AS ItemCnsc2        
      ,#FIN.ProductId    AS ProductId2        
      ,#FIN.Barcode    AS BarCode2        
      ,#FIN.ProductName   AS ProductName2        
      ,#FIN.pe_Quantity   AS pe_Quantity       -- CANTIDAD SOLICITADA        
      ,#FIN.pe_tot     AS pe_tot        
      ,#FIN.pe_price    AS pe_price        
      ,#FIN.Observacion   AS Observations2        
      ,#FIN.UnitMeasure   AS UnitMeasure2        
      ,#FIN.Supplied    AS ItemSupplied        
      ,0       AS c_price        
      ,#FIN.PosObservDesc   AS PosObservDesc        
      ,ue.UeNo       AS UeNo        
    FROM #FIN        
    LEFT JOIN OrderFacts_UE ue on ue.OrderNo = #FIN.OrderNo        
    WHERE Supplied = 0       
 -- HU.40510 no devolver productos de garantias  
 and not #FIN.Barcode in (select distinct x.WarrantyBarcode from OrderFacts_OrderOptionProducts x where x.OrderNo = ue.OrderNo)  
  
    ORDER BY PosObservDesc, ProductName        
  -- ********************************************************************        
        
            
  -- ********************************************************************        
  -- CANTIDADES TOTALES        
  -- ********************************************************************        
            
   SELECT         
    @TotNormal   = SUM(ISNULL(pe_tot,0)),        
    @TotNormalSurtido = SUM(ISNULL(e_tot,0)),        
    @TotPOS    = SUM(ISNULL(c_tot,0)),        
    @TotOferta   = SUM(ISNULL(pe_tot,0)),        
    @TotOfertaSurtido = SUM(ISNULL(e_tot,0)),        
    @TotPagado = CASE         
        WHEN @TotPOS = 0 THEN @TotNormal        
        ELSE @TotPOS        
        END         
   FROM #FIN        
        
   SELECT @PuntosGanados = SUM(ISNULL(PosAdditionalPoints, 0)) FROM OrderFacts_POSPromotions where OrderNo = @OrderNo        
        
   IF @TotPOS > 0        
   BEGIN        
    SELECT @Ahorro = CASE         
         WHEN (@TotNormalSurtido - @TotPOS) > 0 THEN (@TotNormalSurtido - @TotPOS)        
         ELSE 0        
         END;        
   END        
   ELSE        
   BEGIN        
    SELECT @Ahorro = CASE         
         WHEN (@TotNormalSurtido - @TotPagado) > 0 THEN (@TotNormalSurtido - @TotPagado)        
         ELSE 0        
         END;        
   END        
        
   SELECT        
    @OrderNo   as [OrderNo],        
    @TotNormal   as [TotNormal],        
    @TotOferta   as [TotOferta],        
    @TotNormalSurtido as [TotNormalSurtido],        
    @TotOfertaSurtido as [TotOfertaSurtido],        
    @TotPOS    as [TotPOS],        
    @TotPagado   as [TotPagado],        
    @Ahorro    as [Ahorro],        
    @PuntosGanados  as [PuntosGanados],        
    @PuntosAcumulados as [PuntosAcumulados]        
        
  -- ********************************************************************        
  -- OBSERVACIONES DE LA ORDEN        
  -- ********************************************************************        
   SELECT        
      ORDCOM.Desc_CarObs  AS [OrderComments],        
      ORDCOM.CnscOrder   AS [CnscOrder],        
      ORDCOM.Id_Cnsc_CarObs AS [Id_Cnsc_CarObs]        
     FROM dbo.TYC_OrdersComments ORDCOM        
   WHERE ORDCOM.OrderNo = @OrderNo        
   AND Id_Cnsc_CarObs <> 0        
  -- ********************************************************************        
            
        
  -- ********************************************************************        
  -- COMENTARIOS DE LA ORDEN        
  -- ********************************************************************        
   SELECT         
    CnscOrder        
    ,BarCode        
    ,OrderNo        
    ,ProductId        
    ,Id_Cnsc_ArtCar_Obser        
    ,Desc_ArtCarObser= CASE WHEN Id_Cnsc_ArtCar_Obser=100 THEN        
     'Ajuste de peso hacia arriba'        
    ELSE        
     CASE WHEN Id_Cnsc_ArtCar_Obser =101 THEN         
      'Ajuste de peso hacia abajo'        
     ELSE         
      Desc_ArtCarObser        
     END        
    END          
         
   FROM TYC_OrderProductsComments        
   WHERE  OrderNo=@OrderNo        
   ORDER BY Id_Cnsc_ArtCar_Obser  DESC        
  -- ********************************************************************        
       
          
  -- ********************************************************************        
  -- SETC BLOQUEAR CAPTURA DE CONFRIMACIÓN DE ENTREGA   
  -- ********************************************************************        
 SELECT    
      UNINFO.Id_Num_Un       AS [IdTienda],        
      UNINFO.Id_Num_UNInfo   AS [IdInfo],        
      UNINFO.UnPerm_Info     AS [Habilitado]        
 FROM UnPerm_Info UNINFO        
 WHERE UNINFO.Id_Num_Un = @StoreNum       
 AND UNINFO.Id_Num_UNInfo = 76       
 ORDER BY UNINFO.Id_Num_Un  
  -- ********************************************************************   
  
-- ********************************************************************    
-- APP DELIVERY   
-- ********************************************************************    
 -- 2024-01-15 confirmar llenado de tablas app delivery  
-- ********************************************************************    
 IF EXISTS (SELECT * FROM OrderFacts_UE_DeliveryMovements DM WHERE dm.UeNo = @UeNo)   
 BEGIN  
    SELECT TOP (1) 1                AS  En_Espera,  
     FORMAT(DM.DeliveryDateEvent, 'dd/MMM/yyyy hh:mm tt')   AS  FechaIntento,  
     case   
    when not RT.UENO IS NULL AND @StatusUe = 4 then   
     case   
      when RT.reasignafecha > DM.deliverydateevent then  
       'reasignar transportista'  
      else  
       DM.StatusDesc  
     end  
    else DM.StatusDesc  
     end AS  Estatus,  
     case   
    when not RT.UENO IS NULL then   
     case   
      when RT.reasignafecha > DM.deliverydateevent then  
       ' '  
      else  
       DM.Cause  
     end  
    else DM.Cause  
     end AS  Motivo  
  FROM OrderFacts_UE_DeliveryMovements DM  
  LEFT JOIN OrderFacts_UE_reasignacionTransporte RT ON RT.UeNo = DM.UeNo  
  WHERE DM.UeNo = @UeNo   
  ORDER BY DM.DeliveryDateEvent DESC  
 END  
 ELSE  
 BEGIN  
  SELECT 0 AS En_Espera  
 END  
  
 IF EXISTS (SELECT * FROM OrderFacts_UE_reasignacionTransporte RT WHERE RT.UeNo = @UeNo)   
 BEGIN  
    SELECT TOP 1 1 AS  Reasigna,  
         UE.EstatusApp     
  FROM OrderFacts_UE UE  
  WHERE UE.UeNo = @UeNo   
 END  
 ELSE  
 BEGIN  
  SELECT TOP 1 0 AS  Reasigna,  
       UE.EstatusApp     
  FROM OrderFacts_UE UE  
  WHERE UE.UeNo = @UeNo  
 END  
  
  
 select DeliveryStatus, CourrierName, DeliveryId, CourrierVehicleType, 'Uber Direct Interfaz' Trans, Uuid from OrderFacts_UE_TrackingUber   
 where UeNo=@UeNo 
	--and DeliveryStatus !='canceled'  --se debe Omitir Develop_ARG
    
   IF OBJECT_ID('tempdb.dbo.#T', 'U') IS NOT NULL        
    DROP TABLE #T;        
   IF OBJECT_ID('tempdb.dbo.#FIN', 'U') IS NOT NULL        
    DROP TABLE #FIN;        
   
  EXEC upCorpOms_Cns_MethodPaymentByOrder @OrderNo=@auxUeNo;

end 


