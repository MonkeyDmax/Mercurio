#!/bin/bash


# Lista de órdenes a marcar como pendientes
ORDENES=(
"610480710"
"610501710"
"610491510"
"610296510"
"610276410"
"610298610"
"610511010"
"610346910"
"610279310"
"610274210"
"610431910"
"610331710"
"610528510"
"610479310"
"610350910"
"610274710"
"610419810"
"610525510"
"610594710"
"610362210"
"610367710"
"610483210"
"610486910"

    # Agrega más órdenes aquí
)

# Endpoint base
ENDPOINT_BASE="https://us-central1-tareas5s-1538431952081.cloudfunctions.net/api/dejaPendiente"

# Recorre cada orden y ejecuta el POST
for ORDEN in "${ORDENES[@]}"; do
    echo "Marcando como pendiente la orden: $ORDEN"
    curl --location --request POST "$ENDPOINT_BASE/$ORDEN" \
    --header "Authorization: Bearer FWYZK6JOKyPVIALzHRRbCQ=="
    echo -e "\n---\n"
done