

#!/bin/bash

# Token de autorización (reemplaza con el tuyo)

# Lista de órdenes a actualizar
ORDENES=( 
"0006102837"
"0006102844"
"0006102947"
"0006103235"
"0006103494"
)

# Endpoint base
ENDPOINT_BASE="https://www.soriana.com/s/-/dw/data/v21_6/sites/Soriana/orders"

# Recorre cada orden y ejecuta el PUT
for ORDEN in "${ORDENES[@]}"; do
    echo "Actualizando orden: $ORDEN"
    curl --location --request PUT "$ENDPOINT_BASE/$ORDEN/export_status" \
    --header "Content-Type: application/json" \
    --header "Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJEMWhPUDdEODN4TjBqZWlqaTI3WWFvZFRjL0E9In0.eyJleHAiOjE3NjA3MzExNTIsIm5iZiI6MTc2MDcyOTM1MiwiaWF0IjoxNzYwNzI5MzUyLCJhdXRoX3RpbWUiOjE3NjA3MjkzNTIsImp0aSI6InRycnRjYzo1NjJjZWU3Yi1kODA0LTRiODYtOGYxNi0wYmVlMWZkMjc0OGUiLCJpc3MiOiJodHRwczovL2FjY291bnQuZGVtYW5kd2FyZS5jb206NDQzL2R3c3NvL29hdXRoMiIsImF1ZCI6IjRhYTFmYWFmLWZlOTctNDA4Mi1hNmM1LTEzMTc0MGI1YzEyYSIsInN1YiI6IjRhYTFmYWFmLWZlOTctNDA4Mi1hNmM1LTEzMTc0MGI1YzEyYSIsInR5cCI6IkJlYXJlciIsImF6cCI6IjRhYTFmYWFmLWZlOTctNDA4Mi1hNmM1LTEzMTc0MGI1YzEyYSIsImN0cyI6Ik9BVVRIMl9TVEFURUxFU1NfR1JBTlQiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwiYXVkaXRUcmFja2luZ0lkIjoiZGVwcmVjYXRlZCIsInNjb3BlIjpbIm1haWwiXSwic3VibmFtZSI6IjRhYTFmYWFmLWZlOTctNDA4Mi1hNmM1LTEzMTc0MGI1YzEyYSIsInRva2VuTmFtZSI6ImFjY2Vzc190b2tlbiIsInJlYWxtIjoiLyIsInRva2VuX3R5cGUiOiJCZWFyZXIiLCJleHBpcmVzX2luIjoxODAwLCJhdXRoR3JhbnRJZCI6ImRlcHJlY2F0ZWQiLCJjbGllbnRfaWQiOiI0YWExZmFhZi1mZTk3LTQwODItYTZjNS0xMzE3NDBiNWMxMmEifQ.HCWuIBk-Zt6tCWA3Z9ZjCFFvZH0gP-Gce-wvynA9xswBmTKzBET4i1oN8cxjlVD0ikz38KriyMeK4UOeLnBOfVeaKDQkLA3r7rFvUQKy3XkZOWTb2vOj9NwM_mo2XiLqU_t-nOUFWrJIUE0nIQALwZvd7eYooTwTO4IAU1Jv3vLBV5jbp6Rdt4Tct-HLxbtGWweKBLuLypckF3yDZhz1jQf80eJuE5ApR8EVL3A-R9vLQdcTaSKpnqxwXH79VT9p5HAMnWPyuLXcWnEZ-entt2ysh4HgxjwS8VLoH22dD6HNQTlS6TY8qKgyzNGNo_hmSEAubaLgpq9ZGFr0s-fXpg" \
    --data '{"status": "ready"}'
    echo -e "\n---\n"
done