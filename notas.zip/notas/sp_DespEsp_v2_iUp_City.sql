


CREATE PROCEDURE [dbo].[sp_DespEsp_v2_iUp_City]
 @Id_Num_Orden int  
 ,@UeNo VARCHAR(25)  
AS  
--
-- ----------------------------------------------------------------------  
-- Pruebas Unitarias  
-- sp_DespEsp_iUp 101060400  

BEGIN
	DECLARE  @BaseSegCobXArt SMALLINT  
	  ,@BaseMinCob  SMALLINT  
	  ,@LimMinIniEnt  SMALLINT  
	  ,@LimArtSurt10M  SMALLINT  
	  ,@BaseMinSurt  SMALLINT  
	  ,@BaseMinSurtSec SMALLINT  
	  ,@BaseSegSurtSec SMALLINT  
	  ,@BaseMinSurtFre SMALLINT  
	  ,@BaseSegSurtFre SMALLINT  
	  ,@BaseMinAsig  SMALLINT  
	  ,@Procede   TINYINT  
  
	DECLARE  @Fec_Entrega  smallDATETIME  
	  ,@CantArtOrden  SMALLINT  
	  ,@CantPzasOrden  SMALLINT  
	  ,@CantArtFrescos SMALLINT  
	  ,@CantArtSecos  SMALLINT  
	  ,@CantSeg   SMALLINT  
	  ,@HoraIniCobro  smallDATETIME  
	  ,@HoraEnvio   smallDATETIME  
	  ,@HoraIniSurtido smallDATETIME  
	  ,@HoraAsignacion smallDATETIME  
	  ,@uetype   VARCHAR(20)  
	  ,@CnscOrder         BIGINT  
	  ,@CnscOrder2        BIGINT  
	  ,@CheckTransition INT = 0  
	  ,@StatusUE   TINYINT  
	  ,@CreatedBy   INT  
	  ,@CreatedByX  varchar(25)  
	  ,@StoreNum          INT  
	  ,@Direccion         varchar(70)  
	  ,@IdTipoFormato     int  
	  ,@Director          varchar(70)  
	  ,@Region            varchar(70)  
	  ,@CostoEnvio        money
	  ,@StoreNumOrder     INT;  
  
	SET NOCOUNT ON  
  
	SELECT  
	  @Procede = COUNT(1)  
	 FROM  
	  OrderFacts_Order Orden 
	 WHERE  
	  Orden.OrderNo = @Id_Num_Orden  
	  -- And Orden.CreatedBy   
	  --  in ('2','21','22','23','24','25','storefront','Soriana')  
	  AND (case when isnumeric(Orden.CreatedBy) = 1 then ISNULL(Orden.CreatedBy,'0') else '24' end  
	  IN ( '2', '21', '22', '23', '24', '27', 'Soriana', 'storefront' ))  
  
	 SET @uetype = ISNULL((SELECT UETYPE FROM ORDERFACTS_UE WHERE UENO = @UENO),' ');  
	 SET @CnscOrder = ISNULL((SELECT CnscOrder FROM ORDERFACTS_UE WHERE UENO = @UENO),' ');  
	 SELECT TOP 1 @StatusUE=ISNULL(StatusUe,0), @CreatedBy=ISNUMERIC(CreatedBy), @CreatedByX = CreatedBy, @StoreNum  = StoreNum  
	 FROM ORDERFACTS_UE WHERE UENO = @UENO; -- MODIF. 29-09-2021  
  
	 SELECT TOP 1   
	  @Direccion=u.Direccion,  
	  @Director=u.Director,  
	  @IdTipoFormato=u.IdTipoFormato,  
	  @Region=u.Region  
	 from dbo.UN u where u.Id_Num_UN=@StoreNum;  
  
	-- El calculo de los tiempos estimados solo proceden para las ordenes de SuperEnTuCasa  
	IF @Procede = 0  
	  RETURN    

	-- si la orden no tiene el valor correcto de tienda en Orderfacts_order. <2023-01-07><inicio>
	SELECT TOP 1 @StoreNumOrder  = StoreNumber FROM OrderFacts_Order o WHERE o.OrderNo=@Id_Num_Orden
	if @StoreNum <> @StoreNumOrder
	begin
		update OrderFacts_Order
		set StoreNumber=u.StoreNum
		from OrderFacts_Order o
		inner join OrderFacts_UE u on u.OrderNo = o.OrderNo
		where o.OrderNo = @Id_Num_Orden
		and o.StoreNumber <> u.StoreNum;
	end
	-- si la orden no tiene el valor correcto de tienda en Orderfacts_order. <2023-01-07><inicio>

	SELECT @BaseSegCobXArt = 16 -- 16 segundos por cada articulo de la orden para el cobro  
	SELECT @BaseMinCob = 15  -- 15 minutos antes del Inicio de Entrega  
	SELECT @LimArtSurt10M = 5 -- 5 Cantidad de artículos limite para obtener el tiempo de surtido fijo y no en base a los artículos de la orden.  
	SELECT @BaseMinSurt = 10 -- 10 minutos antes del Inicio de Cobro siempre y cuando la cantidad de articulos en la orden sea menor a @LimArtSurt10M.  
	SELECT @BaseMinSurtSec = 1 -- 1 minutos por artículo de Surtido Secos  
	SELECT @BaseSegSurtSec = 19 -- 19 segundos por artículo de Surtido Secos  
	SELECT @BaseMinSurtFre = 1 -- 1 minutos por artículo de Surtido Frescos  
	SELECT @BaseSegSurtFre = 45 -- 45 segundos por artículo de Surtido Frescos  
	SELECT @BaseMinAsig = 5  -- 5 minutos antes del Inicio de Surtido  
	SELECT @LimMinIniEnt = 75 -- 60 minutos antes del Inicio de la Entrega que es la Fecha y Hora que el cliente seleccionó  
  
	 -- Obtener la fecha de entrega que determminó el Cliente  
		SELECT  
	   @Fec_Entrega = CONVERT(DATETIME,(CONVERT(VARCHAR(10),CalEntrega.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),CalEntrega.OrderDeliveryTime))) --Fec_Entrega  
	  FROM  
	   OrderFacts_UE CalEntrega  
	  WHERE  
	   Calentrega.OrderNo = @Id_Num_Orden  
	   and CalEntrega.UeNo = @UeNo  

	--   print 'paso fec'
  
	 --  
	 -- Obtener cantidad de articulos y de piezas de la Orden  
	 -- Para artículos Frescos que son aquellos que pertenezcan a una de las lineas de la tabla apsLineasEspeciales  
	 -- la cantidad de piezas es independiente al peso que se haya solicitado del producto de tal forma que siempre  
	 -- será 1.  
	 -- Para los artículo Secos que son los que no pertenecen a las lineas de la tabla apsLineasEspeciales, la catidad  
	 -- de piezas pedidas por el cliente sí es lo que está en el campo Cant_Unidades de la tabla ArtCar_d.  
	 --   
	 -- Cantidad de articulos y piezas Frescos  
	 /*  
	 SELECT  
		@CantArtOrden = COUNT(1)  
	   ,@CantPzasOrden = COUNT(1)  
	  FROM  
	   OrderFacts_Order Orden  
	  JOIN TYC_OrderProducts TYC  
	  ON  TYC.CnscOrder = Orden.CnscOrder  
	  JOIN apsLineasEspeciales APS  
	  ON  APS.Id_Num_Linea = TYC.Id_Num_Linea  
	  WHERE  
		Orden.OrderNo = @Id_Num_Orden  
	 */  
	  SELECT @CantArtOrden = COUNT(1)  
	  ,@CantPzasOrden = COUNT(1)  
	  FROM OrderFacts_UE ue  
	  join OrderFacts_UE_ItemsToSupply its on  
	  its.OrderNo = @Id_Num_Orden  
	  and its.CnscOrder = @CnscOrder  
	  where ue.OrderNo = @Id_Num_Orden  
	  and ue.UeNo = @UeNo  
  
	-- -------------------------------------------------------------------  
	 -- Cantidad de articulos y piezas Secos  
  
	 if @uetype IN ('SETC','DST')  
	  begin  
	/*  
	   SELECT @CantArtFrescos = SUM(Quantity)  
	   from OrderFacts_UE_ItemsToSupply its   
	   where  its.OrderNo = @Id_Num_Orden  
		and its.CnscOrder = @CnscOrder;  
  
	   set @CantArtSecos = 0;  
	*/  
  
	  SELECT  
		   @CantArtSecos   = POST.DryQty  
		,@CantArtFrescos = POST.FreshQty  
	   FROM OrderFacts_POSOrderStatus POST  
	   WHERE  
		POST.OrderNo = @Id_Num_Orden  
	   AND POST.UeNo    = @UeNo;  
	  end  
	 else  
	  begin  
	   SELECT @CantArtSecos = SUM(Quantity)  
	   from OrderFacts_UE_ItemsToSupply its   
	   where  its.OrderNo = @Id_Num_Orden  
		and its.CnscOrder = @CnscOrder;  
  
	   set @CantArtFrescos = 0;  
	 end  
  
	 /*  
	 SELECT  
		@CantArtOrden   = POST.OrderQtyItems  
	   ,@CantPzasOrden  = POST.OrderQtyPieces  
	   ,@CantArtSecos   = POST.DryQty  
	   ,@CantArtFrescos = POST.FreshQty  
	  FROM  
	   OrderFacts_Order Orden  
	  LEFT JOIN    OrderFacts_POSOrderStatus POST  
	  ON  POST.CnscOrder = Orden.CnscOrder  
	  WHERE  
		Orden.OrderNo = @Id_Num_Orden  
	 */  
  
  
	-- -----------------------------Obtener los artículos SecosObtener los artículos Secos--------------------------------------  
  
	 -- Obtener los artículos Secos  
	-- SELECT @CantArtSecos = @CantArtOrden - @CantArtFrescos  

	--  print 'llego a la 201'

	 -- Obtener la cantidad de segundos de cobro  
	 SELECT @CantSeg = @BaseSegCobXArt * @CantPzasOrden  
	 -- La fecha y hora esperada del Envío/Entrega es de @LimMinIniEnt Min antes de la fecha y hora establecida por el Cliente.  
	 SELECT @HoraEnvio = DATEADD(mi,-@LimMinIniEnt,@Fec_Entrega)  

	-- print 'llego al final'

	 -- La fecha y hora esperada del inicio de cobro se calcula en base a la fecha y hora estimada de Envioo/Entrega  
	 -- se le resta el tiempo empleado en cobrar y a eso se le resta la Base Minima de cobro.  
	 SELECT @HoraIniCobro = DATEADD(mi,-@BaseMinCob,DATEADD(ss,-@CantSeg,@HoraEnvio))  
	 -- La Fecha y hora esperada del Inicio de Surtido es en un inicio 10 min antes del inicio del cobro  
	 SELECT @HoraIniSurtido =  DATEADD(mi,-@BaseMinSurt,@HoraIniCobro)  
	 -- Si la cantidad de piezas de la orden rebasan el limite del surtido, se recalcula.  

	--     print 'paso fec2'

	 --SELECT @HoraEnvio, @HoraIniCobro, @HoraIniSurtido  
  
	 IF @CantPzasOrden > @LimArtSurt10M  
	   BEGIN  
	  -- Si la cantidad de articulos de la orden es mayor a 5 se consideran tiempos por cada articulo dependiendo si es Seco o Fresco  
	  -- Se toma como base el tiempo del Cobro  
	  SELECT  @HoraIniSurtido = @HoraIniCobro  
  
	  -- Considerar Secos  
	  IF @CantArtSecos > 0  
		SELECT @HoraIniSurtido = DATEADD(mi,-(@CantArtSecos*@BaseMinSurtSec),DATEADD(ss,-(@CantArtSecos*@BaseSegSurtSec),@HoraIniSurtido))  
	  -- Considerar Frescos  
	  IF @CantArtFrescos > 0  
		SELECT @HoraIniSurtido = DATEADD(mi,-(@CantArtFrescos*@BaseMinSurtFre),DATEADD(ss,-(@CantArtFrescos*@BaseSegSurtFre),@HoraIniSurtido))  
	   END  

	--    print 'paso fec3'

	 SELECT @HoraAsignacion = DATEADD(mi,-@BaseMinAsig,@HoraIniSurtido)  
  
	 -- Si la orden ya tiene el calculo de los tiempos, lo borra y lo vuelve a instertar  
	 DELETE  
	   DespEsp  
	  WHERE  
		Id_Num_Orden = @Id_Num_Orden  
	 -- Inserta los tiempos calculados  
	 INSERT INTO  
	   DespEsp  
	 VALUES (  
		@Id_Num_Orden  
	   ,@HoraAsignacion --Fec_EspAsig  
	   ,@HoraIniSurtido --Fec_EspSurt  
	   ,@HoraIniCobro  --Fec_EspCob  
	   ,@HoraEnvio   --Fec_EspEnv  
	   ,@CantArtOrden  --CantArtOrden  
	   ,@CantPzasOrden  --CantPzasOrden  
	   ,@CantArtSecos  --CantArtSecos  
	   ,@CantArtFrescos --CantArtFrescos  
	   ,dbo.fn_GetTimeZoneByStoreNumOrder(0, @Id_Num_Orden) --Fec_Movto  
	   --,GETDATE()   --Fec_Movto  
	   )  

	--     print 'paso fec4'
  
	/*  
	   select  
		@Id_Num_Orden  as orderno  
	   ,@HoraAsignacion as Fec_EspAsig  
	   ,@HoraIniSurtido as Fec_EspSurt  
	   ,@HoraIniCobro  as Fec_EspCob  
	   ,@HoraEnvio   as Fec_EspEnv  
	   ,@CantArtOrden  as CantArtOrden  
	   ,@CantPzasOrden  as CantPzasOrden  
	   ,@CantArtSecos  as CantArtSecos  
	   ,@CantArtFrescos as CantArtFrescos  
	   ,dbo.fn_GetTimeZoneByStoreNumOrder(0, @Id_Num_Orden) as Fec_Movto  
	*/  
  
  
	-- Actualización del flete   
	--LCAK--ISITA --11012023 -- Se declaran nuevos parametros para buscar el max cnscorder  
	declare @PosBarcode bigint = 2000020509772,  
	  @existeFlete smallint = null,  
	  @ordenValida smallint = null,  
	  @ShipmentID varchar(75) = null,
	  @MaxCnscOrder BIGINT,
	  @CoincideCnscOrder BIGINT = null,
	  @OrdenOriginal BIGint;

	SET @CnscOrder2 = ISNULL((SELECT CnscOrder FROM OrderFacts_Order WHERE OrderNo = @Id_Num_Orden),0);  
	set @ordenValida = ISNULL((select count(ue.OrderNo) from OrderFacts_UE ue where   
	  ue.OrderNo = @id_num_Orden  
	 and ue.UeNo = @UeNo  
	 and ue.UeType = @uetype  
	 and (ue.DeliveryType LIKE '%domicilio%' OR ue.DeliveryType LIKE '%homeDelivery%')  
	 and (isnumeric(ue.CreatedBy) = 0 or ue.CreatedBy='27') ), 0);  

	--    print 'paso fec5'

	SET @ShipmentID = ISNULL(  
	(SELECT TOP 1 ProdItemShipmentId from OrderFacts_OrderProducts where CnscOrder IN (@CnscOrder2)  
	and ProdItemBarcode in (SELECT TOP 1 PosBarcode FROM OrderFacts_POSProducts WHERE CnscOrder IN (@CnscOrder2) and not PosBarcode in (@PosBarcode))  
	),'');  
  
	-- set @existeFlete = isnull((select count(PosBarcode) from OrderFacts_POSProducts where OrderNo=@id_num_Orden and PosBarcode=@PosBarcode), 0);  
	set @existeFlete = isnull((select count(PosBarcode) from OrderFacts_POSProducts where CnscOrder=@CnscOrder2 and PosBarcode=@PosBarcode), 0);  
  
	set @ordenValida = case when @CnscOrder2 > 0 then @ordenValida else 0 end;  
  
	--select @ordenValida ordenValida, @CnscOrder2 CnscOrder2, @existeFlete existeFlete, trim(@ShipmentID) ShipmentID, @CreatedBy CreatedBy, @CreatedByX CreatedByX  

	--LCAK--ISITA --11012023
	--INICIO
	--Se busca el no original de la orden (sin consignación)
	-- SET @OrdenOriginal = left(@Id_Num_Orden,6);
	select @OrdenOriginal = convert(bigint,(SUBSTRING(u.UeNo,1,(CHARINDEX ( '-' , u.UeNo)) -1))) from OrderFacts_UE u where u.OrderNo=@Id_Num_Orden;
	--se busca el max cnscorder de la orden original
	SET @MaxCnscOrder = ISNULL((SELECT MAX(CnscOrder) FROM OrderFacts_Order WHERE CurrentOrderNo = @OrdenOriginal),0); 
	--Se busca que coincida el max con el cnscorder2
	SET @CoincideCnscOrder = case when @CnscOrder2 = @MaxCnscOrder then @MaxCnscOrder else 0 end;


  
	if @ordenValida > 0  
	begin  
	 if @existeFlete = 0  
	 begin  
	  if @CreatedBy = 0 -- ordenes salesforce  
	  begin  
	   --select 'insercion' as opcion;  
	   if @CoincideCnscOrder > 0  --Si coincide con la ultima consignación, se agrega el costo que no va en 0
	   begin  
		Select coincide = 'si';
		insert into dbo.OrderFacts_POSProducts  
		select top 1  
		 @CnscOrder2         as CnscOrder,  
		 @PosBarcode         as PosBarcode,  
		 @Id_Num_Orden        as OrderNo,  
		 'TRASPORTE 1 SERVICIO A DOMICILIO TARIFA' as PosProductDescription,  
		 1            as PosQuantity,  
		 s.GrossPrice        as PosPriceNormalSale,  
		 s.GrossPrice        as PosPriceOfferSale,  
		 0            as PosRounding,  
		 0            as PosBitBestPrice,  
		 0            as PosBitProductSupplied,  
		 0            as PosBitRecApproved,  
		 0           as PosObservID,  
		 'FLETES SERVICIOS'       as PosObservDesc,  
		 22203          as PosLineNumber,  
		 ue.[UeNo]         as UeNo  
		from OrderFacts_OrderShipping s  
		left join orderfacts_order o on o.cnscorder = s.cnscorder  
		left join OrderFacts_UE ue on ue.OrderNo = o.OrderNo  
		where o.OrderNo = @id_num_Orden  
		and ue.UeType =  @uetype
		and (ue.DeliveryType LIKE '%domicilio%' OR ue.DeliveryType LIKE '%homeDelivery%')  
		and (isnumeric(ue.CreatedBy) = 0 or ue.CreatedBy='27')
		and s.NetPrice > 0
	   end  
	   else  
	   begin
		Select coincide = 'no'; --si no coincide con la ultima consignación agrega el costo del flete en 0
		insert into dbo.OrderFacts_POSProducts  
		select top 1  
		 @CnscOrder2         as CnscOrder,  
		 @PosBarcode         as PosBarcode,  
		 @Id_Num_Orden        as OrderNo,  
		 'TRASPORTE 1 SERVICIO A DOMICILIO TARIFA' as PosProductDescription,  
		 1            as PosQuantity,  
		 s.GrossPrice        as PosPriceNormalSale,  
		 s.GrossPrice        as PosPriceOfferSale,  
		 0            as PosRounding,  
		 0            as PosBitBestPrice,  
		 0            as PosBitProductSupplied,  
		 0            as PosBitRecApproved,  
		 0           as PosObservID,  
		 'FLETES SERVICIOS'       as PosObservDesc,  
		 22203          as PosLineNumber,  
		 ue.[UeNo]         as UeNo  
		from OrderFacts_OrderShipping s  
		left join orderfacts_order o on o.cnscorder = s.cnscorder  
		left join OrderFacts_UE ue on ue.OrderNo = o.OrderNo  
		where o.OrderNo = @id_num_Orden  
		and ue.UeType =  @uetype
		and (ue.DeliveryType LIKE '%domicilio%' OR ue.DeliveryType LIKE '%homeDelivery%')  
		and (isnumeric(ue.CreatedBy) = 0 or ue.CreatedBy='27')
		and s.NetPrice = 0
	   end  ---FIN--LCAK--ISITA --11012023 
	  end  
	  else  
	  begin  
		select top 1 @CostoEnvio=s.CostoEnvio   
		from [tms].[TiendasCostoEnvio] s  
		where  
		(  
		-- combinaciones especificas por cada variable  
		 (s.IdTipoFormato=@IdTipoFormato) or  
		 (s.StoreNum=@StoreNum) or  
		 (s.Director=@Director) or  
		 (s.Direccion=@Direccion) or  
		 (s.Region=@Region)   
		 -- faltan armar las combinaciones donde se conjugan estas variables.  
		)  
		and s.BitActivo=1  
		order by s.FechaCreacion desc;  
  
		insert into dbo.OrderFacts_POSProducts  
		select top 1  
		 @CnscOrder2         as CnscOrder,  
		 @PosBarcode         as PosBarcode,  
		 @Id_Num_Orden        as OrderNo,  
		 'TRASPORTE 1 SERVICIO A DOMICILIO TARIFA' as PosProductDescription,  
		 1            as PosQuantity,  
		 @CostoEnvio         as PosPriceNormalSale,  
		 @CostoEnvio         as PosPriceOfferSale,  
		 0            as PosRounding,  
		 0            as PosBitBestPrice,  
		 0            as PosBitProductSupplied,  
		 0            as PosBitRecApproved,  
		 0           as PosObservID,  
		 'FLETES SERVICIOS'       as PosObservDesc,  
		 22203          as PosLineNumber,  
		 @UeNo          as UeNo;  
	  end  
	 end  
	 else  
	 begin  
	  --select 'update' as opcion;  
	  update dbo.OrderFacts_POSProducts  
	set   
	   PosRounding = 0,  
	   PosBitBestPrice = 0,  
	   PosBitProductSupplied = 0,  
	   PosBitRecApproved = 0  
	  where OrderNo=@id_num_Orden   
	   and PosBarcode=@PosBarcode;  
	 end  
	end  
  
	if @uetype in ('CEDIS','DSV')  
	BEGIN  
	  update dbo.OrderFacts_POSProducts  
	  set   
	   PosRounding = 0,  
	   PosBitBestPrice = 0  
	  where OrderNo=@id_num_Orden   
	END  
  
	-- *************************************************************  
	-- **** checar si la tabla transicion esta vacia para la orden.  
	-- *************************************************************  
	IF (@Id_Num_Orden>0) AND (@CnscOrder>0)  
	BEGIN  
	 SET @CheckTransition = isnull((SELECT COUNT(*) FROM OrderFacts_UE_Transition t WHERE T.OrderNo=@Id_Num_Orden AND T.UeNo = @UeNo ),0);  
  
	 IF @CheckTransition=0  
	 BEGIN  
	  EXEC [dbo].[spInsertOrderFacts_UE_Transition] @UeNo, @Id_Num_Orden  
	 END  
	END  
  
	-- *************************************************************  
	-- **** 2021-08-12 correctivo a totales de cada shipment.  
	-- **** 1. tabla de productos POS. OrderFacts_POSMethodPayment.PaymentMethodAmount  
	-- **** 2. tabla de la unidad de ejecucion.OrderFacts_UE.Total  
	-- *************************************************************  
   
	 -- A. Si la orden tiene solo 1 shipment, no hay tareas que ejecutar.  
	 -- @Cnscorder2 - consecutivo de la orden OrderFacts_Order.  
	 DECLARE @Shipments  int = null,  
	   @ShippingCost money = null,  
	   @ItemsTotal  money = null,  
	   @PaymentMethodDesc varchar(40);  
  
	 SELECT @Shipments=ISNULL(COUNT(ShipmentId),0) FROM OrderFacts_OrderShipments WHERE CnscOrder = @CnscOrder2;  
  
	 -- B. Si la orden tiene mas de 1 shipment, se necesita el correctivo.  
  
	 IF @Shipments>1  
	  BEGIN  
	   --SELECT TOP 1 @ShippingCost=ISNULL(s.NetPrice,0)   
	   --FROM OrderFacts_POSProducts p  
	   --left join OrderFacts_OrderProducts pp on pp.CnscOrder = @CnscOrder2  
	   --and pp.ProdItemBarcode = p.PosBarcode  
	   --left join OrderFacts_OrderShipping s on s.ShipmentId = pp.ProdItemShipmentId and s.CnscOrder = @CnscOrder2  
	   --WHERE p.orderno=@Id_Num_Orden AND p.UeNo=@UeNo;  


	  -- Autor: Juan Martín Rodríguez Loredo
	  -- Empresa: ISITA
	  -- Fecha Mod: 30/09/2022 10:30
	   SELECT TOP 1 @ShippingCost=ISNULL(s.TotalShipNetPrice,0)   
	   FROM OrderFacts_POSProducts p  
	   left join OrderFacts_OrderProducts pp on pp.CnscOrder = @CnscOrder2 AND pp.ProdItemBarcode = p.PosBarcode
	   -- Bug 4239: Bajada de ordenes. Revisión de llenado de columna Total en tabla OrderFacts_UE.
	   -- Correción de relación para evitar obtener 2000020509772 / TRASPORTE 1 SERVICIO A DOMICILIO TARIFA
	   INNER JOIN OrderFacts_OrderShipments s on s.ShipmentId = pp.ProdItemShipmentId and s.CnscOrder = @CnscOrder2  
	   WHERE p.orderno=@Id_Num_Orden AND p.UeNo=@UeNo;  
  
	   SELECT @ItemsTotal= (SUM(ISNULL((P.PosQuantity * P.PosPriceNormalSale),0)))  
	   FROM OrderFacts_POSProducts p   
	   WHERE p.OrderNo=@Id_Num_Orden and p.UeNo=@UeNo;  
  
		-- Autor: Juan Martín Rodríguez Loredo
		-- Empresa: ISITA
		-- Fecha Mod: 30/09/2022 10:30
		-- Bug 4239: Bajada de ordenes. Revisión de llenado de columna Total en tabla OrderFacts_UE.
		-- Valida que el resulta sea mayor a cero para realizar la actualización
		IF @ShippingCost > 0
			BEGIN
				UPDATE OrderFacts_POSMethodPayment
				--SET PaymentMethodAmount = (@ShippingCost + @ItemsTotal)  
				SET PaymentMethodAmount = (@ShippingCost)  
				WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo;  
			
				UPDATE OrderFacts_UE
				SET Total = (@ShippingCost)  
				WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo; 
			END 
		----------------------------------------------------------------------------------------------
	  END  

	  
	-- *********************************************************************************************
	-- modificacion 2022-12-20, actualizar el address2 de las tablas de shipments, y consignaciones.
	-- *********************************************************************************************
	if @uetype in ('CEDIS','DSV','DST')  
	BEGIN

		-- *********************************************************************************************************  
		-- MODIF. 05-07-2022 - Agregar invocacion para insercion de tabla [OrderFacts_UE_OrderPaymentPDP]
		-- excepto: ordenes de SERVICIOS, y tambien ordenes con forma de pago PIS - Pago en Tienda
		-- *********************************************************************************************************  
		declare @OrderId          int,
			@ResponseCode     nvarchar(255) = 'AUTORIZADA',
			@ResponseMessage  nvarchar(255) = 'EXITOSO',
			@Fec_movto        datetime = null;

		SELECT TOP 1 @PaymentMethodDesc=PaymentMethodDesc   
			FROM OrderFacts_POSMethodPayment PMP  
			WHERE PMP.OrderNo=@Id_Num_Orden and PMP.UeNo=@UeNo;  
		
		SELECT top 1
				@Fec_movto = CONVERT(DATETIME,(CONVERT(VARCHAR(10),u.OrderDate) + 'T' + CONVERT(VARCHAR(12),u.OrderTime))),
				@OrderId = isnull(t.OrderNoPOS,0)
			FROM OrderFacts_UE u
			LEFT JOIN OrderFacts_UE_Transition t on t.OrderNo=u.OrderNo and t.UeNo=u.UeNo
			WHERE u.OrderNo = @id_num_Orden
			and u.UeNo = @UeNo

		exec dbo.upCorpOms_Ins_OrderPaymentApproved @OrderId, @ResponseCode, @ResponseMessage, @Fec_movto;

	-- *********************************************************************************************
  
	 if @CreatedByX='27' -- actualizar el id de la forma de pago en las ordenes que provienen de pedidos telefonicos.  
	 begin  
	  SELECT TOP 1 @PaymentMethodDesc=PaymentMethodDesc   
	  FROM OrderFacts_POSMethodPayment PMP  
	  WHERE PMP.OrderNo=@Id_Num_Orden and PMP.UeNo=@UeNo;  
  
	  IF @PaymentMethodDesc = 'Efectivo/Vales'  
	  BEGIN  
	   UPDATE OrderFacts_POSMethodPayment  
	   SET PaymentMethodDesc='Efectivo'  
	   WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo;  
	  END  
  
	  UPDATE OrderFacts_POSMethodPayment  
	  SET PaymentMethodId=fp.Id_Num_FormaPago  
	  FROM OrderFacts_POSMethodPayment PMP  
	  LEFT JOIN dbo.FormaPago fp on fp.Abrev_FormaPago=PMP.PaymentMethodDesc  
	  WHERE PMP.OrderNo=@Id_Num_Orden and PMP.UeNo=@UeNo;  
	 end  

		if @CreatedByX='27' -- If para actualizar OrderFacts_POSClient con datos del cliente y tarjeta de lealtad 
			begin  
				DECLARE
					@IDOriginalOrder INT,
					@CustomerNo INT,
					@CustomerFirstName VARCHAR(30),
					@CustomerLastname1 VARCHAR(30),
					@CustomerLastname2 VARCHAR(30),
					@TarjetaLealtad		VARCHAR(100)

				SET @IDOriginalOrder = ISNULL((SELECT OriginalOrderNo FROM OrderFacts_Order WHERE ORDERNO = @Id_Num_Orden),' ');

				select @CustomerNo = Ord.Id_Num_Cte, @CustomerFirstName = Cte.Nom_Cte, @CustomerLastname1 = Cte.Ap_Paterno, @CustomerLastname2 = Cte.Ap_Materno, 
				@TarjetaLealtad = Em.TarjetaLealtad
				FROM Carrito.Orden Ord
				LEFT JOIN Carrito.Cte Cte on Cte.Id_Num_Cte = Ord.Id_Num_Cte
				LEFT JOIN Carrito.Email Em on Em.Id_Num_Cte = Ord.Id_Num_Cte
				WHERE Ord.Id_Num_Orden = @IDOriginalOrder; 
				UPDATE OrderFacts_POSClient 
				SET 
					CustomerNo = @CustomerNo,
					CustomerFirstName = @CustomerFirstName,
					CustomerLastname1 = @CustomerLastname1,
					CustomerLastname2 = @CustomerLastname2,
					CustomerPersonalId = @TarjetaLealtad
					--CustomerTotalPoints = 1
				WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo;   
			end
  
  
	-- *************************************************************  
	-- **** 2021-08-24 Correctivo para pedidos de tipo DSV, numero de tienda.  
	-- **** 1. tabla de ordenes. OrderFacts_Order.  
	-- **** 2. tabla de ue. OrderFacts_ue / OrderFacts_ue_kardex.  
	-- **** 3. tabla de POS. OrderFacts_POSOrderStatus.  
	-- **** 4. tabla de POS. TYC_OrderHeader  
	-- *************************************************************  
	if @uetype in ('DSV')  
	BEGIN  
	  update dbo.OrderFacts_Order  
	  set   
	   StoreNumber = 8001  
	  where OrderNo=@id_num_Orden;  
  
	  update dbo.OrderFacts_UE  
	  set   
	   StoreNum = 8001  
	  where OrderNo=@id_num_Orden and UeNo=@UeNo;  
  
	  update dbo.OrderFacts_UE_Kardex  
	  set   
	   StoreNum = 8001  
	  where OrderNo=@id_num_Orden and UeNo=@UeNo;  
  
  
	  update dbo.OrderFacts_POSOrderStatus  
	  set   
	   StoreNum = 8001  
	  where OrderNo=@id_num_Orden and UeNo=@UeNo;  
  
  
	  update dbo.TYC_OrderHeader  
	  set   
	   Id_Num_UN = 8001  
	  where OrderNo=@id_num_Orden and UeNo=@UeNo;  
  
	END  
  
	if @uetype in ('CEDIS')  
	BEGIN  
	 -- ***************************************************************************************   
	 -- **** 1. Se actualiza la fecha de aprobacion de pago.  
	 -- ****************************************************************************************  
	 DECLARE -- @StoreNum INT = 0,  
	   @DateMov datetime = null;  
  
	 --SET @StoreNum = ISNULL((SELECT TOP 1 StoreNum FROM OrderFacts_UE WHERE OrderNo=@id_num_Orden and UeNo=@UeNo),0);  
	 SET @DateMov = dbo.fn_GetTimeZoneByStoreNumOrder(0,0);  
  
	 EXEC [dbo].[upCorpOms_upd_OrdersToPayApproved] @id_num_Orden, @UeNo, @StoreNum, @DateMov;  
  
	 -- ****************************************************************************************  
	 -- **** 2. Se actualiza en automatico la orden para pasar a status=1 (surtidor asignado)  
	 -- ****************************************************************************************  
	 -- EXEC [dbo].[upCorpOms_upd_OrdersToSupplyFulfilled] @id_num_Orden;  
  
	END  
  
	-- *********************************************************************************************************  
	-- Actualizar las unidades de medida, conversion de cantidades solicitadas, y monto que que paga el cliente 
	-- *********************************************************************************************************  
  
	declare @SalesForce int = 0;  
	set @SalesForce = isnull((select ISNUMERIC(ue.createdby)   
	  from OrderFacts_UE ue where   
	   ue.OrderNo = @id_num_Orden  
	  and ue.UeNo = @UeNo),0);  

	IF @SalesForce = 0  
	BEGIN  
	 EXEC dbo.upCorpOms_Upd_UeNoProductsConversion @UeNo, @id_num_Orden;  

	 -- Revision y depuracion de los ajustes de precio que pueden estar duplicados.
	 --EXEC dbo.upCorpOms_Del_OrderPriceAdjustmensItems @id_num_Orden;  
	END  
  
	-- *********************************************************************************************************  
	-- Actualizar TABLA de los estatus de la orden, ordenes OSF que estan en estatus 0 - orden nueva  
	-- *********************************************************************************************************  
	if @StatusUE=0 and @CreatedBy=0  
	begin  
	 -- *********************************************************************
	 -- Se registra por 1ra ocasion en tablas del cambio de estatus
	 -- *********************************************************************
	  EXEC [dbo].[upCorpOms_Ins_ShipmentStatus] @UeNo, 1, 0;    
	 -- *********************************************************************
	 -- Se registra la informacion de logistica
	 -- *********************************************************************
	  if @uetype = 'DST'
		  begin
			EXEC [dbo].[upCorpOms_Ins_UeNoShipmentTracking] @id_num_Orden;
		  end
	 -- *********************************************************************
	 -- Se actualiza el CP desde el shipment del articulo
	 -- *********************************************************************
	 EXEC [dbo].[upCorpOms_Upd_UeNoDeliveryPCbyOrder] @id_num_Orden;
	 -- *********************************************************************
	 -- Validar las tablas de price adjustments
	 -- *********************************************************************
	 EXEC [dbo].[upCorpOms_Del_UeNoPriceAdjustmensItems] @id_num_Orden;

	  -- *********************************************************************
	 -- Validar las tablas de pos PROMOTIONS
	 -- *********************************************************************
	 EXEC [dbo].[upCorpOms_Upd_UeNoPOSPromotions] @id_num_Orden, @UeNo;
 
	end  


	-- ********************************************************************************************************
	-- BUG.mantener.cantidades.e.importes.del.pedido.original.
	-- ********************************************************************************************************
	declare @totIni int;
	if @StatusUE = 0 and @uetype in ('SETC','DST')
		begin
			EXEC [dbo].[upCorpOms_Ins_OrderProdsInitFromPOS] @id_num_Orden;
		
			select @totIni = count(OrderNo) from OrderFacts_POSProdsInit where OrderNo = @id_num_Orden;
			if @totIni = 0
				EXEC [dbo].[upCorpOms_Ins_OrderProdsInit] @id_num_Orden;

		end
	-- ********************************************************************************************************
	-- ********************************************************************************************************

  
  
	-- *********************************************************************************************************  
	-- Actualizar cantidad en efectivo y vales, para ordenes provenientes de pedidos telefonicos.  
	-- *********************************************************************************************************  
	if @CreatedBy=1 and @CreatedByX='27'  
	begin  
	 -- *********************************************************************    
	 -- *********************************************************************    
	  EXEC [dbo].[upCorpOms_Upd_CashVoucherPayment] @UeNo  
	  -- *********************************************************************    
	  EXEC [dbo].[upCorpOms_Upd_PtelProductsConversion] @UeNo, @id_num_Orden;
	  --EXEC [dbo].[upCorpOms_Upd_OrderProducts] @id_num_Orden  
	 -- *********************************************************************    
	 -- *********************************************************************      
	end  

	-- *********************************************************************************************************  
	-- Actualizar estatus de orden de SERVICIOS.
	-- FIX.2022-04-29 - añadir cambio de estatus a orden entregada
	-- *********************************************************************************************************  
	-- FIX.2022-04-29 - cambiar estatus de consignacion SERVICIOS a entregada - inicio
	DECLARE @OrderClosingType OrderClosingTableType,
			@Accion		SMALLINT = 1;

	DECLARE @lista as table
	(
		UeNo         varchar(25),
		StoreNum     int,
		ShipperName  varchar(90),
		DeliveryDate datetime,
		IdReceive    varchar(90),
		NameReceive  varchar(90),
		Comments     varchar(50)
	)

	DECLARE 
		@ShipperName  varchar(90),
		@DeliveryDate datetime,
		@IdReceive    varchar(90),
		@NameReceive  varchar(90),
		@Comments     varchar(50);
	-- FIX.2022-04-29 - cambiar estatus de consignacion SERVICIOS a entregada - final

	 if @uetype IN ('SERVICIOS')  
	 begin
		EXEC dbo.upCorpOms_upd_OrdersToPayment @Id_Num_Orden, 1;

		-- FIX.2022-04-29 - cambiar estatus de consignacion SERVICIOS a entregada - inicio
		INSERT INTO @lista select @UeNo,@StoreNum,'SYSTEM',null,'','','ARTICULOS ENTREGADOS';

		UPDATE @lista
		-- cambio temporal - definitivo
		-- set DeliveryDate=GETDATE() AT TIME ZONE 'UTC' AT TIME ZONE 'Central Standard Time (Mexico)',
		set DeliveryDate= (select dbo.fn_GetTimeZoneByStoreNumOrder(0,0)),
			IdReceive = 'TO: '+ue.CustomerName,
			NameReceive = 'TO: '+ue.CustomerName
		from @lista l
		left join OrderFacts_UE ue on ue.UeNo=l.UeNo;

		SELECT TOP 1 
			@ShipperName=L.ShipperName, @DeliveryDate=L.DeliveryDate, @IdReceive=L.IdReceive, @NameReceive=L.NameReceive, @Comments=L.Comments
		FROM @lista L;

		delete @OrderClosingType;
		insert into @OrderClosingType (UeNo,StoreNum,ShipperName,DeliveryDate,IdReceive,NameReceive,Comments) values (@UeNo, @StoreNum, @ShipperName, @DeliveryDate, @IdReceive, @NameReceive, @Comments)

		exec upCorpOms_upd_OrdersToDeliveredStatus @OrderClosingType, @Accion;
		-- FIX.2022-04-29 - cambiar estatus de consignacion SERVICIOS a entregada - final
	 end



		-- *********************************************************************************************
		-- modificacion 2022-12-20, actualizar el address2 de las tablas de shipments, y consignaciones.
		-- *********************************************************************************************
		DECLARE
			@cont int,
			@tot int,
			@OrderNo int,
			@OrdenXML nvarchar(max);

		declare @tblTmpCEDIS as table
		  (
			OrderNo int NOT NULL,
			Colonia varchar(100) NOT NULL
		  )

		-- tabla temporal de analisis
		declare @tblOrd as table
		  (
			idtbl int IDENTITY(1,1) NOT NULL primary key,
			OrderNo int NOT NULL INDEX OrdOrderNo (OrderNo),
			cnscorder bigint NULL,
			orderdate date NULL,
			idOwner int NULL,
			storenum int NULL,
			UeType varchar(20) NULL,
			ShipmentId varchar(75) NULL,
			address1 varchar(100) NULL,
			address2 varchar(100) NULL,
			orderxml xml
		  )

		-- se llena desde Orderfacts_UE
		INSERT INTO @tblOrd
		select u.OrderNo, 
			o.CnscOrder, 
			u.OrderDate, 
			u.idOwner, 
			case when UeType = 'DSV' then u.idSupplierWH else u.StoreNum end, 
			u.UeType,
			q.ProdItemShipmentId,
			u.Address1, 
			u.Address2, 
			x.OrderMessage
		from OrderFacts_UE u
		inner join orderfacts_ue_xml x on x.OrderNo=u.OrderNo
		inner join OrderFacts_Order o on o.OrderNo = u.OrderNo
		inner join OrderFacts_OrderProducts q on 
			  q.CnscOrder = (select top 1 CnscOrder 
								from dbo.OrderFacts_OrderProducts q 
								where CnscOrder in (select top 1 CnscOrder from OrderFacts_Order where OrderNo=u.OrderNo))  
			  and  
			  q.ProdItemBarcode = (select top 1 p.Barcode from dbo.OrderFacts_UE_ItemsToSupply p where p.OrderNo = u.OrderNo
			  and not p.Barcode in (select distinct c.BarCode from dbo.OrderFacts_CarrierCodes c) )
		where u.UeType in ('DST','CEDIS','DSV') 
		and u.UeNo = @UeNo
		and LEN(ISNULL(rtrim(ltrim(u.Address2)),'')) = 0;

		-- se completan desde mensaje XML de la orden.
		SET @tot = ISNULL((select COUNT(*) from @tblOrd),0);
		SET @cont = 1

		-- Si la orden en curso tiene vacio el address2 de orderfacts_UE, entonces se procede a llenarlo.
		if @tot > 0
		BEGIN
			while @cont <= @tot
			BEGIN
				SELECT TOP 1 @OrderNo=ISNULL(OrderNo,0)
				FROM @tblOrd WHERE idtbl=@cont;

				SET @OrdenXML = NULL;

				delete from @tblTmpCEDIS;

				select top 1 
					@OrdenXML = REPLACE(CAST( x.OrderMessage as nvarchar(max)),'http://www.demandware.com/xml/impex/order/2006-10-31','')
					from OrderFacts_UE_XML x where x.OrderNo in (@orderNo);

				DECLARE @hdoc int= 1

				-- recalcular el registro de logistica
				EXEC sp_xml_preparedocument @hdoc OUTPUT, @OrdenXML
				--;WITH XMLNAMESPACES(DEFAULT 'http://www.demandware.com/xml/impex/order/2006-10-31')

				insert @tblTmpCEDIS
					SELECT 
					@orderNo,
					case when [shipping-address].value('(shipping-address/custom-attributes/custom-attribute)[1]', 'varchar(100)') is null then ''
					else [shipping-address].value('(shipping-address/custom-attributes/custom-attribute)[1]', 'varchar(100)')
					end
					FROM OPENXML (@hdoc, '/orders/order/shipments/shipment' , 3)
					WITH(
						[shipment-id] varchar(200),
						[shipping-address] xml
						)
					WHERE  [shipment-id] = @shipmentId;

				EXEC sp_xml_removedocument @hdoc

				update @tblOrd
				set address2 = (select top 1 Colonia from @tblTmpCEDIS)
				where OrderNo = @OrderNo;

				SET @cont = @cont +1;
			END

			-- ******************************************************************************
			-- actualizar las tablas respectivas
			-- ******************************************************************************
			-- OrderFacts_OrderShipments, a traves del cnscOrder.
			UPDATE OrderFacts_OrderShipments
			SET ShipAddressAddress2=ships.address2
			FROM OrderFacts_OrderShipments s
			inner join (select distinct cnscorder, ShipmentId, address2 from @tblOrd) ships
			on ships.cnscorder=s.CnscOrder and ships.ShipmentId=s.ShipmentId
			where LEN(ISNULL(rtrim(ltrim(s.ShipAddressAddress2)),'')) = 0

			-- OrderFacts_UE, atraves del OrderNo.
			UPDATE OrderFacts_UE
			SET Address2=substring(ships.address2,1,40)
			FROM OrderFacts_UE s
			inner join (select distinct OrderNo, UeType, address2 from @tblOrd) ships
			on ships.OrderNo=s.OrderNo and ships.UeType=s.UeType
			where LEN(ISNULL(rtrim(ltrim(s.Address2)),'')) = 0
		END
	END

	-- ********************************************************************************************************
	-- modificacion 2023-02-13, actualizacion del POSClient en caso de que el nro.tarjeta lealtad este vacio.
	-- ********************************************************************************************************
	declare @valPOSClient bit=0, @membership varchar (40), @orderjson nvarchar(max), @orderid2 varchar(20);

	-- Tratar de tomarlo del json de la orden
	set @valPOSClient = ISNULL(
	(select 
		case when CustomerPersonalId is null then 1
				when CustomerPersonalId = '0' then 1
				when CustomerPersonalId = '00' then 1
				when CustomerPersonalId = '' then 1
				else 0
		end
		from OrderFacts_POSClient 
		WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo)
	,0);

	if @valPOSClient = 1
	begin
		select @orderid2 = RIGHT(('0000000000' + convert(varchar, a.OrderNoPOS)),10)
		from OrderFacts_UE_Transition a
		where a.OrderNo = @Id_Num_Orden 
		and a.UeNo = @UeNo;

		select @membership = JSON_value(convert(nvarchar(max), a.SF_Json), '$.data.c_membershipID')
			from tbl_Descarga_Order_SF a
			where a.order_no = @orderid2;

		UPDATE OrderFacts_POSClient 
		SET 
			CustomerPersonalId = @membership,
			CustomerTotalPoints = 0
		WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo; 
	end

	set @valPOSClient = ISNULL(
	(select 
		case when CustomerPersonalId is null then 1
				when CustomerPersonalId = '0' then 1
				when CustomerPersonalId = '' then 1
				else 0
		end
		from OrderFacts_POSClient 
		WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo)
	,0);

	if @valPOSClient = 1
	begin
		UPDATE OrderFacts_POSClient 
		SET 
			CustomerPersonalId = '00',
			CustomerTotalPoints = 0
		WHERE OrderNo=@Id_Num_Orden and UeNo=@UeNo; 
	end;
END


