

SELECT 
    fk.name AS ForeignKeyName,
    sch_from.name AS Esquema_Origen,
    tab_from.name AS Tabla_Origen,
    col_from.name AS Columna_Origen,
    sch_to.name AS Esquema_Destino,
    tab_to.name AS Tabla_Destino,
    col_to.name AS Columna_Destino,
    fk_obj.create_date AS FK_CreateDate
FROM sys.foreign_keys fk
INNER JOIN sys.objects fk_obj ON fk.object_id = fk_obj.object_id
INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
INNER JOIN sys.tables tab_from ON fkc.parent_object_id = tab_from.object_id
INNER JOIN sys.schemas sch_from ON tab_from.schema_id = sch_from.schema_id
INNER JOIN sys.columns col_from ON fkc.parent_object_id = col_from.object_id AND fkc.parent_column_id = col_from.column_id
INNER JOIN sys.tables tab_to ON fkc.referenced_object_id = tab_to.object_id
INNER JOIN sys.schemas sch_to ON tab_to.schema_id = sch_to.schema_id
INNER JOIN sys.columns col_to ON fkc.referenced_object_id = col_to.object_id AND fkc.referenced_column_id = col_to.column_id
WHERE sch_from.name = 'dbo' OR sch_to.name = 'dbo'
ORDER BY fk_obj.create_date ,tab_to.name ;