https://azkv350o01.vault.azure.net/secrets/usr-ServiciosLealtad/b8cd3f88f35a4f149ee94253edf6829a



  Console.WriteLine("Creating token credential.");
  var secretValue = configuration["VaultName"];

  var user = configuration["User"];
  var database = configuration["Database"];
  var server = configuration["Server"];

  Uri vaultUri = new Uri($"https://{secretValue}.vault.azure.net/");



  const string secretName = "usr-ServiciosLealtad";
  var keyVaultName = "azkv350o01";
  var kvUri = $"https://{keyVaultName}.vault.azure.net";


  var tenantID = "63f2639c-dfdd-4e88-a1e7-ce5bc248841a>";
  var appID = "1943daaa-62c1-4282-892a-82fe12e886c3";
  var appSec = "LoyaltyPRD";

  var userCred = new ClientSecretCredential(tenantID, appID, appSec);

  var client2 = new SecretClient(new Uri(kvUri), userCred);

  Console.Write(client.GetSecret(secretName).Value.Value);

  TokenCredential azureCredential = new DefaultAzureCredential();

  //azureCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions
  //{
  //    ManagedIdentityClientId = configuration["ManagedIdentityClientId"],
  //    TenantId = configuration["TenantId"]
  //});


  //var cred = new DefaultAzureCredential(new DefaultAzureCredentialOptions
  //{
  //    ManagedIdentityClientId = configuration["AZURE_CLIENT_ID"],
  //    TenantId = configuration["AZURE_TENANT_ID"],
  //    ExcludeSharedTokenCacheCredential = true
  //});

  //var cred = new VisualStudioCredential(new VisualStudioCredentialOptions { TenantId = "d304cb51-c9ec-4c15-bfdd-a8d6e80018ab" });

  var cliente = new SecretClient(vaultUri, azureCredential);

//  var credential = new VisualStudioCredential(new VisualStudioCredentialOptions { TenantId = "63f2639c-dfdd-4e88-a1e7-ce5bc248841a" });

//  var secretClient = new SecretClient(new Uri("https://azkv350o01.vault.azure.net/"), credential);
  var secret = client.GetSecret("usr-ServiciosLealtad");
  //var secretp = secret.Value?.Value;

  Console.WriteLine($"secret Key Vault {secret}");

  var secretPassword = client.GetSecret(user).Value.Value;

  conn = $"Data Source={server};" +
          $"Initial Catalog={database};" +
          $"Persist Security Info=True;" +
          $"User ID={user};" +
          $"Password={secretPassword}";

  Console.WriteLine("Cadena de conexion: " + conn);