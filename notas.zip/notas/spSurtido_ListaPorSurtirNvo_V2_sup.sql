Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- *************************************************************************************************************************  
-- Obtiene la información a mostrar en la página de Surtido.  
-- Tomar en cuenta SETC se muestran todas las ordenes y DST solo las que tienen pago aprobado.  
-- GeronimoJauregui - Empresa: ISITA - 17-11-2022:   
-- * Se agrega nueva columna para regresar el número y nombre de la tienda para los casos de Intertienda.  
-- * Se le resta una hora a la hora de entrega de la orden de la tienda Especializada y a la tienda No especializada queda   
--  igual, como originalmente selecciono el cliente.  
--  * A los UPDATE que filtran por número de tienda, se valida que orden corresponde de una tienda no especializada y   
--  que filtre por la tienda Especializada y las ordenes que no cumplan lo filtre por la tienda de consulta al SP.  
-- 2023-10-16 - Ajuste para la hora de entrega estimada a mostrar en ordenes de tipo almacen DST  
-- 2023-11-10 - Ajuste Ordenamiento de resultados.  
-- 2024-03-08 - Se agrega columna Unidades Fijas CH - 40408  
-- 2024-08-05 - Se agrega estatus on hold
-- 2024-08-20 - Se quita join con tabla OrderFacts_UE_OrderPaymentPDP
-- *************************************************************************************************************************  
CREATE PROCEDURE [dbo].[spSurtido_ListaPorSurtirNvo_V2_sup]  
 @Id_Num_UN  SMALLINT  
AS  
  
  
SET NOCOUNT ON  
  
IF OBJECT_ID('tempdb.dbo.#T', 'U') IS NOT NULL  
  DROP TABLE #T;   
  
  
CREATE TABLE #T  
 (  
   Id_Num_Orden    INT  
  ,Num_Nombre_Tienda   VARCHAR(max)  
  ,Id_Num_Car     INT  
  ,Id_Num_UN     SMALLINT  
  ,Id_Num_OrdenStat   TINYINT  
  ,Id_Num_SrvEntrega   TINYINT  
  ,Fec_Entrega    DATETIME  
  ,Id_Num_Surtidor   SMALLINT  
  ,Surtidor     VARCHAR(80)  
  ,Fec_AsigEsp    DATETIME  
  ,Fec_SrtEsp     DATETIME  
  ,Fec_PagoEsp    DATETIME  
  ,Fec_AsigTraspEsp   DATETIME  
  ,Cant_Art     SMALLINT  
  ,Cant_Piezas    SMALLINT  
  ,Cant_Art_Frescos   SMALLINT  
  ,Cant_Art_Secos    SMALLINT  
  ,Fec_AsigReal    DATETIME  
  ,Fec_SrtReal    DATETIME  
  ,Fec_PagoReal    DATETIME  
  ,Fec_AsigTraspReal   DATETIME  
  ,UeType      VARCHAR(20)  
  ,UeNo      VARCHAR(25)  
  ,NroOrden     VARCHAR(25)  
  ,OrdenEntregaProgramada     BIT  
        ,FechaSurtidoEntregaProgramada DATETIME  
  ,FechaEntregaProgramadaCliente DATETIME  
  ,score                     INT  
  ,Especializada      BIT   
  ,DeliveryType              varchar(20)  
  ,EsEspecializada   BIT   
  ,cantidadHoras             int  
  ,BitVencidaOriginal        Bit  
  ,BitVencidoCompromiso      Bit  
  ,statusue                  smallint  
  ,fechaCompromiso           datetime  
  ,NameBase                  varchar(70)  
  ,NameNoEsp                 varchar(70)  
  ,UnidadesFijas             varchar(10)  
 )  
CREATE NONCLUSTERED INDEX ix_tempT ON #T (Id_Num_Orden, UeNo);  
  
--SET LANGUAGE SPANISH;    
  
DECLARE  
  
 @HorasParaSurtir   SMALLINT,  
 @HorasParaCobrar   SMALLINT,  
 @HorasParaEmbarcar  SMALLINT,  
 @Ahora     DATETIME,  
 @Margen                 smallint = -180,  
 @EsEspecializada        bit = isnull((Select top (1) 1 from tms.RelacionTiendasEspecializadas r where r.StoreNumEspecializada = @Id_Num_UN),0),  
 @ZonaHra    varchar(100) = (select ltrim(rtrim(n.UnPerm_Info)) from UnPerm_Info n where n.Id_Num_Un=@Id_Num_UN and n.Id_Num_UnInfo=70);  
declare  
 @HoraZona               datetime = (getdate() at time zone 'UTC' at time zone @ZonaHra);  
 --set @HoraZona = '2023-03-31 16:40:15';   
  
SELECT @HorasParaSurtir  = -5  
SELECT @HorasParaCobrar  = -3  
SELECT @HorasParaEmbarcar = -2  
  
SELECT @Ahora = dbo.fn_GetTimeZoneByStoreNumOrder(CONVERT(INT, @Id_Num_UN), 0);  
  
INSERT INTO  #T  
 SELECT  Orden.OrderNo  
    ,convert(varchar(4),un.id_num_un) + '|' + un.Desc_UN  
    ,0       -- Orden_e.Id_Num_Car   -- NO lo tiene Mercurio  
   ,Orden.StoreNum  
    ,CASE   
     WHEN Orden.StatusUe = 0 then 2  
     WHEN Orden.StatusUe = 1 then 3  
     WHEN Orden.StatusUe = 2 then 3  
     END OrderStatus  
    ,0       -- Orden.Id_Num_SrvEntrega  -- NO lo tiene Mercurio  
    -- 2023-10-16 - Ajuste para la hora de entrega estimada a mostrar en ordenes de tipo almacen DST  
    ,CASE  
     WHEN Orden.UeType = 'SETC' THEN  
      CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),Orden.OrderDeliveryTime)))  
     ELSE  
      CASE WHEN TRK.FechaEntrega IS NULL THEN   
       CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),Orden.OrderDeliveryTime)))  
      ELSE  
       CONVERT(DATETIME,(CONVERT(VARCHAR(10),CONVERT(DATE,TRK.FechaEntrega)) + 'T20:00:00.000'))  
      END  
     END [Fec_Entrega] --Fec_Entrega  
    ,Orden.Id_Supplier   -- Id_Num_Surtidor  
    ,NULL --Surtidor  
    ,NULL --Fec_IniAsigEsp  
    ,NULL --Fec_IniSrtEsp  
    ,NULL --Fec_IniPagoEsp  
    ,NULL --Fec_AsigTraspEsp  
    ,0  --Cant_Art  
    ,0  --Cant_Piezas  
    ,0  --Cant_Art_Frescos  
    ,0  --Cant_Art_Secos  
    ,NULL --Fec_AsigReal  
    ,NULL --Fec_SrtReal  
    ,NULL --Fec_PagoReal  
    ,NULL --Fec_AsigTraspReal  
    ,Orden.UeType  
    ,Orden.UeNo  
    ,CASE  
     WHEN ISNUMERIC(Orden.CreatedBy)=1 THEN CONVERT(VARCHAR, Orden.OrderNo)  
     ELSE Orden.UeNo  
     END NroOrden  
       ,CASE   
       WHEN ofmg.OrderNo IS NOT NULL THEN 1  
       ELSE 0  
       END  
       ,CASE   
       WHEN ofmg.OrderNo IS NOT NULL THEN   
        (SELECT [dbo].[fnGetFechaParaSurtir]   
         (ofmg.OrderNo   
         ,ofmg.FechaEntrega   
         ,Orden.OrderDate  
         ,ofmg.Owner  
         ,ofmg.NumeroTransportista  
         ,Orden.PostalCode))  
        END  
    ,ofmg.FechaEntrega  
    ,0  
    ,case when Orden.StoreNum = @Id_Num_UN then 1 else 0 end  
    ,case  
     when DeliveryType = 'Entrega en tienda' then 'Recoge en tienda'  
     when DeliveryType in ('Entrega a domicilio','Envío a domicilio') then 'Entrega a Domicilio'  
     end [DeliveryType]  
    ,@EsEspecializada  
    ,0  
    ,0  
    ,0  
    ,Orden.StatusUe  
    ,null  
    ,null  
    ,null  
    ,(select count(Id_Vehiculo)  from tms.Vehiculo where Estatus = 1 and IdTienda = @Id_Num_UN and UnidadSor = 1)  
  FROM dbo.OrderFacts_UE Orden  
  INNER JOIN OrderFacts_Order Original on Original.OrderNo = Orden.OrderNo  
  -- 2023-10-16 - Ajuste para la hora de entrega estimada a mostrar en ordenes de tipo almacen DST  
  LEFT JOIN OrderFacts_UE_ShipmentTracking TRK on TRK.OrderNo=Orden.OrderNo and TRK.UeNo=Orden.UeNo  
  LEFT JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo  
  LEFT JOIN UN un on un.Id_Num_Un = Inter.StoreNumTiendaNoEspecializada  
  --Valida si la orden es Entrega Programanda  
        LEFT JOIN dbo.OrderFacts_MercanciaGeneral ofmg on ofmg.OrderNo = Orden.OrderNo  
  WHERE Orden.StoreNum    = @Id_Num_UN  
  AND  Orden.OrderDate  > DATEADD( DAY, @Margen, dbo.fn_GetTimeZoneByStoreNumOrder(CONVERT(INT, @Id_Num_UN), 0))  
  -- Tomar en cuenta SETC se muestran todas las ordenes, y DST solo las que tienen pago aprobado.  
  --AND ((Orden.UeType in ('SETC','DST')))  
  AND ((Orden.UeType in ('SETC'))  
  OR  (Orden.UeType in ('DST')))  
 UNION   
  SELECT  Orden.OrderNo  
     ,convert(varchar(4),un.id_num_un) + '|' + un.Desc_UN  
     ,0       -- Orden_e.Id_Num_Car   -- NO lo tiene Mercurio  
     ,Orden.StoreNum  
     ,CASE   
      WHEN Orden.StatusUe = 0 then 2  
      WHEN Orden.StatusUe = 1 then 3  
      WHEN Orden.StatusUe = 2 then 3  
      END OrderStatus  
     ,0       -- Orden.Id_Num_SrvEntrega  -- NO lo tiene Mercurio  
     -- 2023-10-16 - Ajuste para la hora de entrega estimada a mostrar en ordenes de tipo almacen DST  
     ,CASE  
      WHEN Orden.UeType = 'SETC' THEN  
CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),Orden.OrderDeliveryTime)))  
      ELSE  
       CASE WHEN TRK.FechaEntrega IS NULL THEN   
        CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),Orden.OrderDeliveryTime)))  
       ELSE  
        CONVERT(DATETIME,(CONVERT(VARCHAR(10),CONVERT(DATE,TRK.FechaEntrega)) + 'T20:00:00.000'))  
       END  
      END [Fec_Entrega] --Fec_Entrega  
     ,Orden.Id_Supplier   -- Id_Num_Surtidor  
     ,NULL --Surtidor  
     ,NULL --Fec_IniAsigEsp  
     ,NULL --Fec_IniSrtEsp  
     ,NULL --Fec_IniPagoEsp  
     ,NULL --Fec_AsigTraspEsp  
     ,0  --Cant_Art  
     ,0  --Cant_Piezas  
     ,0  --Cant_Art_Frescos  
     ,0  --Cant_Art_Secos  
     ,NULL --Fec_AsigReal  
     ,NULL --Fec_SrtReal  
     ,NULL --Fec_PagoReal  
     ,NULL --Fec_AsigTraspReal  
     ,Orden.UeType  
     ,Orden.UeNo  
     ,CASE  
      WHEN ISNUMERIC(Orden.CreatedBy)=1 THEN CONVERT(VARCHAR, Orden.OrderNo)  
      ELSE Orden.UeNo  
      END NroOrden  
        ,CASE   
           WHEN ofmg.OrderNo IS NOT NULL THEN 1  
           ELSE 0  
           END  
           ,CASE   
           WHEN ofmg.OrderNo IS NOT NULL THEN   
            (SELECT [dbo].[fnGetFechaParaSurtir]   
             (ofmg.OrderNo   
             ,ofmg.FechaEntrega   
             ,Orden.OrderDate  
             ,ofmg.Owner  
             ,ofmg.NumeroTransportista  
             ,Orden.PostalCode))  
            END  
     ,ofmg.FechaEntrega  
     ,0  
     ,case when Orden.StoreNum = @Id_Num_UN then 1 else 0 end  
     ,case  
      when DeliveryType = 'Entrega en tienda' then 'Recoge en tienda'  
      when DeliveryType in ('Entrega a domicilio','Envío a domicilio') then 'Entrega a Domicilio'  
      end [DeliveryType]  
     ,@EsEspecializada  
     ,0  
     ,0  
     ,0  
     ,Orden.StatusUe  
     ,null  
     ,null  
     ,null  
     ,(select count(Id_Vehiculo)  from tms.Vehiculo where Estatus= 1 and IdTienda = @Id_Num_UN and UnidadSor = 1)  
   FROM dbo.OrderFacts_UE Orden  
   INNER JOIN OrderFacts_Order Original on Original.OrderNo = Orden.OrderNo  
   -- 2023-10-16 - Ajuste para la hora de entrega estimada a mostrar en ordenes de tipo almacen DST  
   LEFT JOIN OrderFacts_UE_ShipmentTracking TRK on TRK.OrderNo=Orden.OrderNo and TRK.UeNo=Orden.UeNo  
   INNER JOIN OrderFacts_Intertienda t on t.StoreNumTiendaNoEspecializada = @Id_Num_UN AND t.OrderNo = Orden.OrderNo  
   LEFT JOIN UN un on un.Id_Num_Un = t.StoreNumTiendaEspecializada  
      --Valida si la orden es Entrega Programanda  
            LEFT JOIN dbo.OrderFacts_MercanciaGeneral ofmg on ofmg.OrderNo = Orden.OrderNo  
   WHERE Orden.StoreNum = t.StoreNumTiendaEspecializada  
   AND  Orden.OrderDate  > DATEADD( DAY, @Margen, dbo.fn_GetTimeZoneByStoreNumOrder(CONVERT(INT, @Id_Num_UN), 0))  
   -- Tomar en cuenta SETC se muestran todas las ordenes, y DST solo las que tienen pago aprobado.  
   --AND ((Orden.UeType in ('SETC','DST')))  
   AND ((Orden.UeType in ('SETC'))  
   OR  (Orden.UeType in ('DST') ))  
  
UPDATE  #T  
 SET   Fec_Entrega = DATEADD(HOUR, -1, Fec_Entrega)  
 FROM #T t  
 INNER JOIN OrderFacts_Order Original on Original.OrderNo = t.Id_Num_Orden  
 INNER JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo   
   AND Inter.StoreNumTiendaEspecializada = @Id_Num_UN  
 WHERE not Num_Nombre_Tienda is null  
  
-- *************************************************************************************************************************  
-- ELISEO.20210217.17:25 -- estos son datos que NO TIENE Mercurio, o al menos me falta contexto para conocer a que refieren   
-- *************************************************************************************************************************  
UPDATE  #T  
 SET  
    Fec_AsigEsp    = DespEsp.Fec_AsigEsp  
   ,Fec_SrtEsp = CASE WHEN (OrdenEntregaProgramada = 1 AND UeType = 'DST') THEN FechaSurtidoEntregaProgramada ELSE DespEsp.Fec_SrtEsp END  
   ,Fec_PagoEsp    = DespEsp.Fec_PagoEsp  
   ,Fec_AsigTraspEsp = CASE WHEN (OrdenEntregaProgramada = 1 AND UeType = 'DST') THEN   
                        CASE WHEN CAST(FechaEntregaProgramadaCliente AS DATE) = CAST(Fec_Entrega AS DATE)  
                        THEN CONVERT(DATETIME,(CONVERT(VARCHAR(10),(CONVERT(DATE, FechaEntregaProgramadaCliente))) + 'T16:00:00'))  
                        ELSE DATEADD(MINUTE, -75, FechaEntregaProgramadaCliente)  
                        END  
                        ELSE DespEsp.Fec_AsigTraspEsp END  
   ,Cant_Art     = DespEsp.CantArtOrden  
   ,Cant_Piezas    = DespEsp.CantPzasOrden  
   ,Cant_Art_Frescos   = DespEsp.CantArt_Fresco  
   ,Cant_Art_Secos    = DespEsp.CantArt_Seco  
 FROM #T  
 LEFT JOIN DespEsp ON DespEsp.Id_Num_Orden = #T.Id_Num_Orden  
  
UPDATE  #T  
 SET   Fec_Entrega = t.FechaEntregaProgramadaCliente  
 FROM #T t  
 WHERE (t.OrdenEntregaProgramada = 1 AND t.UeType = 'DST')  
  
  
UPDATE  #T  
 SET  
    Fec_AsigReal    = Kardex.OrderMovementDate  
   ,Fec_SrtReal    = ISNULL(CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.PickingDateEnd) + 'T' + CONVERT(VARCHAR(12),Orden.PickingTimeEnd))), Kardex.OrderMovementDate)  
 FROM #T  
 JOIN  OrderFacts_UE (NOLOCK) Orden  
 ON   Orden.OrderNo     = #T.Id_Num_Orden  
 INNER JOIN OrderFacts_Order Original on Original.OrderNo = #T.Id_Num_Orden  
 LEFT JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo  
 LEFT JOIN OrderFacts_UE_Kardex (NOLOCK) Kardex  
 ON   Kardex.CnscOrder    = Orden.CnscOrder  
 AND   Kardex.StoreNum     = isnull(Inter.StoreNumTiendaEspecializada, @Id_Num_UN)  
 AND   Kardex.StatusUe     = 1  
  
  
UPDATE  #T  
 SET  
   Fec_PagoReal    = ISNULL(CONVERT(DATETIME,(CONVERT(VARCHAR(10),Orden.PaymentDateEnd) + 'T' + CONVERT(VARCHAR(12),Orden.PaymentTimeEnd))), Kardex.OrderMovementDate)  
 FROM #T  
 JOIN  OrderFacts_UE (NOLOCK) Orden  
 ON   Orden.OrderNo     = #T.Id_Num_Orden  
 INNER JOIN OrderFacts_Order Original on Original.OrderNo = #T.Id_Num_Orden  
 LEFT JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo  
 LEFT JOIN OrderFacts_UE_Kardex (NOLOCK) Kardex  
 ON   Kardex.CnscOrder    = Orden.CnscOrder  
 AND   Kardex.StoreNum     = isnull(Inter.StoreNumTiendaEspecializada, @Id_Num_UN)  
 AND   Kardex.StatusUe     = 3  
  
  
UPDATE  #T  
 SET  
   Fec_AsigTraspReal   = Kardex.OrderMovementDate  
 FROM #T  
 JOIN  OrderFacts_UE (NOLOCK) Orden  
 ON   Orden.OrderNo     = #T.Id_Num_Orden  
 INNER JOIN OrderFacts_Order Original on Original.OrderNo = #T.Id_Num_Orden  
 LEFT JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo  
 LEFT JOIN OrderFacts_UE_Kardex (NOLOCK) Kardex  
 ON   Kardex.CnscOrder    = Orden.CnscOrder  
 AND   Kardex.StoreNum     = isnull(Inter.StoreNumTiendaEspecializada, @Id_Num_UN)  
 AND   Kardex.StatusUe     = 5  
  
  
UPDATE  #T  
 SET   Surtidor    = Surtidor.[Name]  
 FROM #T  
 INNER JOIN OrderFacts_Order Original on Original.OrderNo = #T.Id_Num_Orden  
 LEFT JOIN OrderFacts_Intertienda Inter on Inter.OrderNo = Original.OrderNo  
 LEFT JOIN  
  OrderFacts_Supplier Surtidor  
 ON  Surtidor.Id_Supplier = #T.Id_Num_Surtidor  
  AND Surtidor.Id_Num_Un  = isnull(Inter.StoreNumTiendaEspecializada, @Id_Num_UN)  
  
-- logica para actualizar la columna scorE  
  
 declare @tblOrderFinal as table  
 (orderNo int, score int)  
  
 INSERT INTO @tblOrderFinal  
 EXEC dbo.up_Corp_cns_OrdersByScore @Id_Num_UN, @Margen;  
  
-- ***********************************************************************************  
-- logica para HU_12513 - control de pedidos pendientes  
-- ***********************************************************************************  
update #T  
set cantidadHoras =   
(select top (1) r.cantidadHoras   
 from RangoTiempoVencimiento r   
 join RangoTiempoVencimiento_FormaEntrega r2 on r.idRango=r2.idRango  
 join PrioridadSurtido_Cat_FormaEntrega t on t.Id=r2.idFormaEntrega  
 where t.Descripcion = DeliveryType  
 and (  
 (r.especializada=1 and EsEspecializada=1)  
 or  
 (r.noEspecializada=1 and EsEspecializada=0)  
 )  
 and r.activo=1);  
  
-- se marcan las ordenes donde la fecha de la tienda  
-- es mayor o igual a la fecha de entrega + 1 hora (para cubrir el slot de entrega)  
update #T  
set BitVencidaOriginal =  
case  
 when (@HoraZona >= (dateadd(HH,(cantidadHoras + 1), Fec_Entrega))) then 1  
 else 0  
end  
--from #T t  
--left join OrderFacts_UE_Compromiso c on c.OrderNo=t.Id_Num_Orden and c.UeNo=t.UeNo  
--where c.OrderNo is null;  
  
-- se marcan las ordenes cuya fecha compromiso, es mayor o igual a la fecha de la tienda;  
-- y que son ordenes que aun estan antes del cobro.  
update #T  
set BitVencidoCompromiso =  
case   
 when (@HoraZona  
 >= (CONVERT(DATETIME,(CONVERT(VARCHAR(10),c.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),c.OrderDeliveryTime))))) then 1  
 else 0  
end  
from #T t  
join OrderFacts_UE_Compromiso c on c.OrderNo=t.Id_Num_Orden and c.UeNo=t.UeNo  
where t.statusue in (0,1,2);  
  
  
 -- fecha compromiso  
 update #T  
 set fechaCompromiso = (CONVERT(DATETIME,(CONVERT(VARCHAR(10),c.OrderDeliveryDate) + 'T' + CONVERT(VARCHAR(12),c.OrderDeliveryTime))))  
 from #T t  
 join OrderFacts_UE_Compromiso c on c.OrderNo=t.Id_Num_Orden and c.UeNo=t.UeNo;  
-- ***********************************************************************************  
-- ***********************************************************************************  
  
-- ***********************************************************************************  
-- TASK: Agregar nombres de tienda especializada y no-especializada  
-- ***********************************************************************************  
  
-- update #T  
-- set NameBase= (select dbo.fn_GetStoreNameByType (Id_Num_Orden, 1)),  
-- NameNoEsp= (select dbo.fn_GetStoreNameByType (Id_Num_Orden, 2))  
   
  
-- ***********************************************************************************  
-- ***********************************************************************************  
  
-- select de salida  
SELECT   t.Id_Num_Orden  
   ,t.Num_Nombre_Tienda  
   ,t.Id_Num_Car  
   ,t.Id_Num_UN  
   ,t.Id_Num_OrdenStat  
   ,t.Id_Num_SrvEntrega  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_Entrega,0)),113) AS Fec_Entrega  -- Zona Horaria Local  
   ,t.Id_Num_Surtidor  
   ,t.Surtidor  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_AsigEsp,0)),113) AS Fec_AsigEsp  -- Zona Horaria Local  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_AsigReal,0)),113) AS Fec_AsigReal -- Zona Horaria Local  
   ,CASE WHEN ISNULL(t.Fec_AsigReal,0) = 0  
    THEN -- NO se tiene la Fecha de Asignacion Real  
     CASE WHEN @Ahora <= DATEADD(mi,-5,t.Fec_AsigEsp)  
      THEN 0 -- Sin Color  
      ELSE  
       CASE WHEN @Ahora <= t.Fec_AsigEsp  
        THEN 2 -- AMARILLO  
        ELSE 3 -- ROJO  
       END  
     END  
    ELSE -- SI se tiene la Fecha de Asignacion Real  
     CASE WHEN t.Fec_AsigReal <= t.Fec_AsigEsp  
      THEN 1 -- VERDE  
      ELSE 3 -- ROJO'  
     END  
    END AS Color_Asig  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_SrtEsp,0)),113) AS Fec_SrtEsp  -- Zona Horaria Local  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_SrtReal,0)),113) AS Fec_SrtReal  -- Zona Horaria Local  
   ,CASE WHEN ISNULL(t.Fec_SrtReal,0) = 0  
    THEN -- NO se tiene la Fecha de Surtido Real  
     CASE WHEN @Ahora <= t.Fec_AsigEsp  
      THEN 0 -- Sin Color  
      ELSE  
       CASE WHEN @Ahora <= t.Fec_SrtEsp  
        THEN 2 -- AMARILLO  
        ELSE 3 -- ROJO  
       END  
      END  
    ELSE -- SI se tiene la Fecha de Surtido Real  
     CASE WHEN t.Fec_SrtReal <= t.Fec_SrtEsp  
      THEN 1 -- VERDE  
      ELSE 3 -- ROJO  
     END  
    END AS Color_Srt  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_PagoEsp,0)),113) AS Fec_FinSrtEsp  -- Zona Horaria Local  
   ,CASE WHEN ISNULL(t.Fec_PagoEsp,0) = 0  
    THEN -- NO se tiene la Fecha de Fin de Surtido Esperado = Fec Inicio Pago  
     CASE WHEN @Ahora  <= DATEADD(mi,-10,t.Fec_PagoEsp)   
      THEN 0 -- Sin Color  
      ELSE  
       CASE WHEN @Ahora <= t.Fec_PagoEsp  
        THEN 2 -- AMARILLO  
        ELSE 3 -- ROJO  
       END  
      END  
    ELSE -- SI se tiene la Fecha de Pago Real  
     CASE WHEN t.Fec_PagoReal <= t.Fec_PagoEsp  
      THEN 1 -- VERDE  
      ELSE 3 -- ROJO  
     END  
    END AS Color_FinSrtEsp  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_PagoEsp,0)),113) AS Fec_PagoEsp   -- Zona Horaria Local  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_PagoReal,0)),113) AS Fec_PagoReal  -- Zona Horaria Local  
   ,CASE WHEN ISNULL(t.Fec_PagoReal,0) = 0  
    THEN -- NO se tiene la Fecha de Pago Real  
     CASE WHEN @Ahora <= t.Fec_SrtEsp  
      THEN 0 -- Sin Color  
      ELSE  
       CASE WHEN @Ahora <= t.Fec_PagoEsp  
        THEN 2 -- AMARILLO  
        ELSE 3 -- ROJO  
       END  
      END  
    ELSE -- SI se tiene la Fecha de Pago Real  
     CASE WHEN t.Fec_PagoReal <= t.Fec_PagoEsp  
      THEN 1 -- VERDE  
      ELSE 3 -- ROJO  
     END  
    END AS Color_Pago  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_AsigTraspEsp,0)),113) AS Fec_AsigTraspEsp -- Zona Horaria Local  
   ,CONVERT(VARCHAR(20),(dbo.fn_GetTimeZoneByStore(@Id_Num_UN,t.Fec_AsigTraspReal,0)),113) AS Fec_AsigTraspReal -- Zona Horaria Local  
   ,CASE WHEN ISNULL(t.Fec_AsigTraspReal,0) = 0  
    THEN -- NO se tiene la Fecha de Asignacion Transportista Real  
     CASE WHEN @Ahora <= t.Fec_PagoEsp  
      THEN 0 -- Sin Color  
      ELSE  
       CASE WHEN @Ahora <= t.Fec_AsigTraspEsp  
        THEN 2 -- AMARILLO  
        ELSE 3 -- ROJO  
       END  
      END  
    ELSE -- SI se tiene la Fecha de Asignacion Transportista Real  
     CASE WHEN t.Fec_AsigTraspReal <= t.Fec_AsigTraspEsp  
      THEN 1 -- VERDE  
      ELSE 3 -- ROJO  
     END  
    END AS Color_AsigTrasp  
   ,t.Cant_Art  
   ,t.Cant_Piezas  
   ,t.Cant_Art_Frescos  
   ,t.Cant_Art_Secos  
   ,t.UeType  
   ,t.UeNo  
   ,t.NroOrden  
   ,t.Especializada  
   ,t.BitVencidaOriginal  
   ,t.BitVencidoCompromiso  
   ,t.fechaCompromiso  
   ,t.NameBase  
   ,t.NameNoEsp  
   ,t.cantidadHoras  
   ,t.UnidadesFijas  
   ,ISNULL(D.IdAsignacion,0) EstatusOnHold
 FROM #T t  
 join @tblOrderFinal tt on tt.orderNo=t.Id_Num_Orden -- se coloca el LEFT JOIN [2023-06-13]  
 LEFT JOIN DetencionOrdenes D
	ON T.UENO = D.UENO
 ORDER BY  
   t.Fec_Entrega ASC, -- de la fecha mas proxima a la fecha mas holgada para entrega al cliente  
   tt.score DESC,      -- del mayor valor de score al menor valor-  
   t.Id_Num_Orden;  
  
  
  
-- lista de ordenes  
IF OBJECT_ID('tempdb.dbo.#T', 'U') IS NOT NULL  
  DROP TABLE #T;   
  
SET NOCOUNT OFF 

