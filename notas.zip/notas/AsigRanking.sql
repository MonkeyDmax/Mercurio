 SELECT * FROM StoreSupplierRating A WHERE A.RatingDate='2024-10-02'				
 SELECT * FROM tbl_History_RankingSuppliers A WHERE A.fec_movto >= '2024-10-02'	


  SELECT * FROM StoreSupplierRating A WHERE A.RatingDate='2024-10-02'				
				
select a.Id_Supplier, b.Name, a.PickingDateEnd, a.* 				
 from OrderFacts_UE a				
 left join OrderFacts_Supplier b on b.Id_Supplier =  a.Id_Supplier				
 where a.OrderDeliveryDate='2024-10-02'				
 and a.UeType in ('SETC','DST')				
 and a.StoreNum=24				
