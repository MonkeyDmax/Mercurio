select * from OrderFacts_Supplier where Id_Num_UN=24 and Activo = 1

--SELECT * FROM  OrderFacts_UE WHERE UeNo='0000464608-1-0'


SELECT TOP 1000 
a.UeNo, a.StoreNum, a.UeType, a.OrderDeliveryDate, a.OrderDeliveryTime, a.PickingDateEnd, a.StatusUe,
a.Id_Supplier, b.name [nombre],
(select COUNT(b.Quantity) from OrderFacts_UE_ItemsToSupply b where b.OrderNo = a.OrderNo) [piezas],
(select top (1) c.OrderMovementDate from OrderFacts_UE_Kardex c where c.OrderNo = a.OrderNo and c.StatusUe=1 order by a.OrderDeliveryDate) [surtido-ini],
(select top (1) c.OrderMovementDate from OrderFacts_UE_Kardex c where c.OrderNo = a.OrderNo and c.StatusUe=2 order by a.OrderDeliveryDate) [surtido-fin]
FROM OrderFacts_UE a
left JOIN OrderFacts_Supplier b on b.Id_Supplier = a.Id_Supplier
where a.OrderDeliveryDate = '2024-09-27'
and a.UeType in ('setc')
and a.StoreNum = 24
order by a.StatusUe, a.OrderDeliveryDate, a.OrderDeliveryTime
